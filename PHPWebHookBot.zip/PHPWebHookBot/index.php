<?php

require_once 'vendor/autoload.php';

// Load environment variables
if (file_exists(__DIR__ . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
}

?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 ELWESHAQSMS - BOT</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #1e2832;
            min-height: 100vh;
            color: #ffffff;
            direction: rtl;
        }
        
        .telegram-header {
            background: #2b5278;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #3a4b5c;
        }
        
        .bot-avatar {
            width: 40px;
            height: 40px;
            background: #8b7355;
            border-radius: 50%;
            margin-left: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        
        .bot-info h2 {
            font-size: 16px;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 2px;
        }
        
        .bot-info p {
            font-size: 13px;
            color: #8aa1b8;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #17212b;
            min-height: 100vh;
        }
        
        .welcome-message {
            background: #2b5278;
            padding: 15px 20px;
            margin: 15px;
            border-radius: 10px;
            text-align: center;
            border-right: 3px solid #ffa500;
        }
        
        .welcome-message h3 {
            color: #ffa500;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .welcome-message p {
            color: #ffffff;
            font-size: 13px;
            line-height: 1.4;
        }
        
        .admin-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            padding: 20px;
            margin-top: 10px;
        }
        
        .admin-btn {
            background: #2b5278;
            border: none;
            border-radius: 8px;
            padding: 20px 15px;
            color: #ffffff;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            min-height: 80px;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .admin-btn:hover {
            background: #3c6890;
            transform: translateY(-2px);
        }
        
        .admin-btn-emoji {
            font-size: 24px;
            margin-bottom: 8px;
        }
        
        .admin-btn-text {
            font-size: 13px;
            font-weight: 500;
            line-height: 1.2;
            color: #ffffff;
        }
        
        .status {
            background: #2b5278;
            border: 1px solid #34c759;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 20px;
            text-align: center;
            font-size: 13px;
            border-right: 3px solid #34c759;
        }
        
        .status.error {
            background: #2b5278;
            border-color: #ff3b30;
            border-right-color: #ff3b30;
        }
        
        .main-menu {
            background: #2b5278;
            padding: 15px 20px;
            margin: 15px;
            border-radius: 8px;
            text-align: center;
            border-right: 3px solid #ffa500;
        }
        
        .main-menu h3 {
            color: #ffa500;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .services-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
            margin-top: 15px;
        }
        
        .service-btn {
            background: #3c6890;
            border: none;
            border-radius: 6px;
            padding: 12px 8px;
            color: #ffffff;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            min-height: 45px;
            transition: all 0.2s ease;
        }
        
        .service-btn:hover {
            background: #4a7ba7;
        }
        
        .telegram-input {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: #17212b;
            padding: 10px 15px;
            border-top: 1px solid #3a4b5c;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .input-field {
            flex: 1;
            background: #2b5278;
            border: none;
            border-radius: 20px;
            padding: 10px 15px;
            color: #ffffff;
            font-size: 14px;
        }
        
        .send-btn {
            background: #34c759;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
        }
        @media (max-width: 600px) {
            .container {
                margin: 0;
                border-radius: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Telegram Header -->
        <div class="telegram-header">
            <div class="bot-avatar">🦁</div>
            <div class="bot-info">
                <h2>ELWESHAQSMS - BOT</h2>
                <p>بوت</p>
            </div>
        </div>
        
        <!-- Welcome Message -->
        <div class="welcome-message">
            <h3>🏆 لوحة الإدارة</h3>
            <p>مرحباً بسيدنا في مركز التحكم المطور ✨</p>
        </div>
        
        <!-- Admin Grid -->
        <div class="admin-grid">
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">🌍</div>
                <div class="admin-btn-text">إدارة البلدان</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">⚙️</div>
                <div class="admin-btn-text">إدارة الخدمات</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">📱</div>
                <div class="admin-btn-text">إدارة الأرقام</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">🔗</div>
                <div class="admin-btn-text">إدارة المجموعات</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">👥</div>
                <div class="admin-btn-text">إدارة المستخدمين</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">📊</div>
                <div class="admin-btn-text">إدارة القنوات</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">💰</div>
                <div class="admin-btn-text">إضافة رصيد</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">💸</div>
                <div class="admin-btn-text">خصم رصيد</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">💬</div>
                <div class="admin-btn-text">رسالة خاصة</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">📢</div>
                <div class="admin-btn-text">رسالة عامة</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">🗂️</div>
                <div class="admin-btn-text">إدارة المخزون</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">📊</div>
                <div class="admin-btn-text">إحصائيات النظام</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">⚙️</div>
                <div class="admin-btn-text">إعدادات النظام</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">🔧</div>
                <div class="admin-btn-text">وضع الصيانة</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">📋</div>
                <div class="admin-btn-text">قناة البيانات</div>
            </a>
            <a href="#" class="admin-btn">
                <div class="admin-btn-emoji">🔐</div>
                <div class="admin-btn-text">الاشتراك الإجباري</div>
            </a>
        </div>
        
        <div style="text-align: center; margin: 20px; padding: 10px; background: #2b5278; border-radius: 8px;">
            <div class="admin-btn-emoji" style="font-size: 30px; margin-bottom: 10px;">🔑</div>
            <div style="color: #ffa500; font-weight: 600; margin-bottom: 5px;">تغيير كلمة المرور</div>
        </div>
        
        <?php
        try {
            // Test database connection
            $db = TelegramBot\Database::getInstance();
            $connection = $db->getConnection();
            $result = $connection->query("SELECT COUNT(*) as count FROM services")->fetch();
            
            echo '<div class="status">';
            echo '✅ التخزين المحلي جاهز!<br>';
            echo "📊 عدد الخدمات المتاحة: " . $result['count'];
            echo '</div>';
            
        } catch (Exception $e) {
            echo '<div class="status error">';
            echo '❌ خطأ في الاتصال بالتخزين المحلي<br>';
            echo htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        ?>
        
        <!-- Main Menu -->
        <div class="main-menu">
            <h3>🌟 القائمة الرئيسية</h3>
            <p style="color: #ffffff; font-size: 13px; margin-bottom: 10px;">اختر خدمة للحصول على رقم مؤقت:</p>
            
            <div class="services-grid">
                <a href="#" class="service-btn">📧 Google</a>
                <a href="#" class="service-btn">🟢 WhatsApp1</a>
                <a href="#" class="service-btn">🎁 رصيد مجاني</a>
                <a href="#" class="service-btn">💰 رصيدي</a>
                <a href="#" class="service-btn">📊 النسب والإحصائيات</a>
                <a href="#" class="service-btn">❓ المساعدة</a>
                <a href="#" class="service-btn">⚙️ لوحة الإدارة</a>
            </div>
        </div>
        
        <!-- Telegram Input -->
        <div class="telegram-input">
            <input type="text" class="input-field" placeholder="الرسالة" />
            <button class="send-btn">🎤</button>
            <button class="send-btn">📎</button>
            <button class="send-btn" style="background: transparent; color: #8aa1b8;">😊</button>
        </div>
    </div>
</body>
</html>
<?php

require_once 'vendor/autoload.php';

use TelegramBot\Database;
use TelegramBot\Config;

// Load environment variables
if (file_exists(__DIR__ . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
}

echo "🗄️  Initializing database...\n";

try {
    $db = Database::getInstance();
    $connection = $db->getConnection();
    
    // Create tables
    $tables = [
        'users' => "
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id TEXT UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                balance REAL DEFAULT 0,
                joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_admin INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                last_reward_at TEXT,
                language_code TEXT DEFAULT 'ar'
            )",
        
        'services' => "
            CREATE TABLE IF NOT EXISTS services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                emoji TEXT DEFAULT '📱',
                description TEXT,
                default_price REAL NOT NULL,
                active INTEGER DEFAULT 1
            )",
        
        'countries' => "
            CREATE TABLE IF NOT EXISTS countries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                code TEXT UNIQUE NOT NULL,
                flag TEXT DEFAULT '🏳️',
                active INTEGER DEFAULT 1
            )",
        
        'service_countries' => "
            CREATE TABLE IF NOT EXISTS service_countries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_id INTEGER REFERENCES services(id),
                country_id INTEGER REFERENCES countries(id),
                country_name TEXT NOT NULL,
                country_code TEXT NOT NULL,
                flag TEXT DEFAULT '🇪🇬',
                active INTEGER DEFAULT 1
            )",
        
        'numbers' => "
            CREATE TABLE IF NOT EXISTS numbers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_id INTEGER REFERENCES services(id),
                country_code TEXT NOT NULL,
                phone_number TEXT NOT NULL,
                status TEXT DEFAULT 'available',
                reserved_by_user_id INTEGER REFERENCES users(id),
                reserved_at TEXT,
                expires_at TEXT,
                code_received_at TEXT,
                price_override REAL,
                usage_count INTEGER DEFAULT 0
            )",
        
        'reservations' => "
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                service_id INTEGER REFERENCES services(id),
                number_id INTEGER REFERENCES numbers(id),
                status TEXT DEFAULT 'waiting_code',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                completed_at TEXT,
                expired_at TEXT,
                code_value TEXT
            )",
        
        'transactions' => "
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                reason TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'channels' => "
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                username_or_link TEXT NOT NULL,
                required INTEGER DEFAULT 1,
                active INTEGER DEFAULT 1,
                reward_amount REAL DEFAULT 5.0
            )",
        
        'groups' => "
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                username_or_link TEXT NOT NULL,
                group_id TEXT NOT NULL,
                required INTEGER DEFAULT 1,
                active INTEGER DEFAULT 1,
                reward_amount REAL DEFAULT 5.0
            )"
    ];
    
    foreach ($tables as $tableName => $sql) {
        echo "Creating table: $tableName...";
        $connection->exec($sql);
        echo " ✅\n";
    }
    
    // Insert default data
    echo "\n📝 Inserting default data...\n";
    
    // Default services
    $defaultServices = [
        ['name' => 'WhatsApp', 'emoji' => '💬', 'default_price' => 5],
        ['name' => 'Telegram', 'emoji' => '📱', 'default_price' => 3],
        ['name' => 'Instagram', 'emoji' => '📷', 'default_price' => 4],
        ['name' => 'Facebook', 'emoji' => '👥', 'default_price' => 4],
        ['name' => 'Twitter', 'emoji' => '🐦', 'default_price' => 6]
    ];
    
    foreach ($defaultServices as $service) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO services (name, emoji, default_price) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$service['name'], $service['emoji'], $service['default_price']]);
        echo "Added service: {$service['name']} ✅\n";
    }
    
    // Default countries
    $defaultCountries = [
        ['name' => 'Egypt', 'code' => 'EG', 'flag' => '🇪🇬'],
        ['name' => 'Saudi Arabia', 'code' => 'SA', 'flag' => '🇸🇦'],
        ['name' => 'UAE', 'code' => 'AE', 'flag' => '🇦🇪'],
        ['name' => 'Kuwait', 'code' => 'KW', 'flag' => '🇰🇼'],
        ['name' => 'Qatar', 'code' => 'QA', 'flag' => '🇶🇦']
    ];
    
    foreach ($defaultCountries as $country) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO countries (name, code, flag) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$country['name'], $country['code'], $country['flag']]);
        echo "Added country: {$country['name']} ✅\n";
    }
    
    // Add some sample numbers for testing
    echo "\n📱 Adding sample numbers...\n";
    $sampleNumbers = [
        '+201234567890', '+201234567891', '+201234567892',
        '+966501234567', '+966501234568', '+966501234569',
        '+971501234567', '+971501234568', '+971501234569'
    ];
    
    $services = $connection->query("SELECT id FROM services LIMIT 3")->fetchAll();
    foreach ($services as $service) {
        foreach (array_slice($sampleNumbers, 0, 3) as $number) {
            $stmt = $connection->prepare("
                INSERT OR IGNORE INTO numbers (service_id, country_code, phone_number, status) 
                VALUES (?, ?, ?, 'available')
            ");
            $stmt->execute([$service['id'], '+20', $number]);
        }
    }
    echo "Added sample numbers ✅\n";
    
    echo "\n🎉 Database initialization completed successfully!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
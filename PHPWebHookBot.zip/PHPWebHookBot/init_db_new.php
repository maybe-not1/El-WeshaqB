<?php

require_once 'vendor/autoload.php';

use TelegramBot\Database;

echo "🗄️  Initializing comprehensive bot database...\n";

try {
    $db = Database::getInstance();
    $connection = $db->getConnection();
    
    // Create comprehensive tables for the telegram bot
    $tables = [
        'users' => "
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id TEXT UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                balance REAL DEFAULT 0,
                joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_admin INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                last_reward_at TEXT,
                language_code TEXT DEFAULT 'ar',
                phone_number TEXT,
                referral_code TEXT,
                referred_by INTEGER,
                total_spent REAL DEFAULT 0
            )",
        
        'services' => "
            CREATE TABLE IF NOT EXISTS services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                emoji TEXT DEFAULT '📱',
                description TEXT,
                default_price REAL NOT NULL,
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'countries' => "
            CREATE TABLE IF NOT EXISTS countries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                code TEXT UNIQUE NOT NULL,
                flag TEXT DEFAULT '🏳️',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'service_countries' => "
            CREATE TABLE IF NOT EXISTS service_countries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_id INTEGER REFERENCES services(id),
                country_id INTEGER REFERENCES countries(id),
                country_name TEXT NOT NULL,
                country_code TEXT NOT NULL,
                flag TEXT DEFAULT '🇪🇬',
                price_override REAL,
                active INTEGER DEFAULT 1
            )",
        
        'numbers' => "
            CREATE TABLE IF NOT EXISTS numbers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_id INTEGER REFERENCES services(id),
                country_code TEXT NOT NULL,
                phone_number TEXT NOT NULL,
                status TEXT DEFAULT 'available',
                reserved_by_user_id INTEGER REFERENCES users(id),
                reserved_at TEXT,
                expires_at TEXT,
                code_received_at TEXT,
                price_override REAL,
                usage_count INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'reservations' => "
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                service_id INTEGER REFERENCES services(id),
                number_id INTEGER REFERENCES numbers(id),
                status TEXT DEFAULT 'waiting_code',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                completed_at TEXT,
                expired_at TEXT,
                code_value TEXT,
                price_paid REAL
            )",
        
        'transactions' => "
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                reason TEXT,
                service_id INTEGER REFERENCES services(id),
                number_id INTEGER REFERENCES numbers(id),
                reference_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'channels' => "
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                username_or_link TEXT NOT NULL,
                required INTEGER DEFAULT 1,
                active INTEGER DEFAULT 1,
                reward_amount REAL DEFAULT 5.0
            )",
        
        'forced_channels' => "
            CREATE TABLE IF NOT EXISTS forced_channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                username_or_link TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                reward_amount REAL DEFAULT 5.0,
                frequency TEXT DEFAULT 'once',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'user_channel_rewards' => "
            CREATE TABLE IF NOT EXISTS user_channel_rewards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                channel_id INTEGER REFERENCES forced_channels(id),
                last_reward_at TEXT,
                times_rewarded INTEGER DEFAULT 0,
                UNIQUE(user_id, channel_id)
            )",
        
        'user_states' => "
            CREATE TABLE IF NOT EXISTS user_states (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE REFERENCES users(id),
                state TEXT DEFAULT 'idle',
                data TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'admin_logs' => "
            CREATE TABLE IF NOT EXISTS admin_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER REFERENCES users(id),
                action TEXT NOT NULL,
                target_type TEXT,
                target_id INTEGER,
                details TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'bot_settings' => "
            CREATE TABLE IF NOT EXISTS bot_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                setting_key TEXT UNIQUE NOT NULL,
                setting_value TEXT,
                description TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )",
        
        'messages_log' => "
            CREATE TABLE IF NOT EXISTS messages_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER REFERENCES users(id),
                message_type TEXT NOT NULL,
                message_text TEXT,
                sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'sent'
            )"
    ];
    
    foreach ($tables as $tableName => $sql) {
        echo "Creating table: $tableName...";
        $connection->exec($sql);
        echo " ✅\n";
    }
    
    // Insert default data
    echo "\n📝 Inserting comprehensive default data...\n";
    
    // Default services with comprehensive list
    $defaultServices = [
        ['name' => 'WhatsApp', 'emoji' => '🟢', 'default_price' => 5, 'description' => 'WhatsApp verification codes'],
        ['name' => 'Telegram', 'emoji' => '✈️', 'default_price' => 3, 'description' => 'Telegram verification codes'],
        ['name' => 'Instagram', 'emoji' => '📷', 'default_price' => 4, 'description' => 'Instagram verification codes'],
        ['name' => 'Facebook', 'emoji' => '🔵', 'default_price' => 4, 'description' => 'Facebook verification codes'],
        ['name' => 'Twitter', 'emoji' => '🐦', 'default_price' => 6, 'description' => 'Twitter verification codes'],
        ['name' => 'TikTok', 'emoji' => '🎥', 'default_price' => 4, 'description' => 'TikTok verification codes'],
        ['name' => 'Google', 'emoji' => '📧', 'default_price' => 3, 'description' => 'Google verification codes'],
        ['name' => 'YouTube', 'emoji' => '📺', 'default_price' => 4, 'description' => 'YouTube verification codes'],
        ['name' => 'Discord', 'emoji' => '🎮', 'default_price' => 3, 'description' => 'Discord verification codes'],
        ['name' => 'Snapchat', 'emoji' => '👻', 'default_price' => 5, 'description' => 'Snapchat verification codes']
    ];
    
    foreach ($defaultServices as $service) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO services (name, emoji, description, default_price) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$service['name'], $service['emoji'], $service['description'], $service['default_price']]);
        echo "Added service: {$service['name']} ✅\n";
    }
    
    // Default countries with proper country codes
    $defaultCountries = [
        ['name' => 'Egypt', 'code' => '+20', 'flag' => '🇪🇬'],
        ['name' => 'Saudi Arabia', 'code' => '+966', 'flag' => '🇸🇦'],
        ['name' => 'UAE', 'code' => '+971', 'flag' => '🇦🇪'],
        ['name' => 'Kuwait', 'code' => '+965', 'flag' => '🇰🇼'],
        ['name' => 'Qatar', 'code' => '+974', 'flag' => '🇶🇦'],
        ['name' => 'Syria', 'code' => '+963', 'flag' => '🇸🇾'],
        ['name' => 'Jordan', 'code' => '+962', 'flag' => '🇯🇴'],
        ['name' => 'Lebanon', 'code' => '+961', 'flag' => '🇱🇧'],
        ['name' => 'Iraq', 'code' => '+964', 'flag' => '🇮🇶'],
        ['name' => 'Morocco', 'code' => '+212', 'flag' => '🇲🇦'],
        ['name' => 'Tunisia', 'code' => '+216', 'flag' => '🇹🇳'],
        ['name' => 'Algeria', 'code' => '+213', 'flag' => '🇩🇿'],
        ['name' => 'Kazakhstan', 'code' => '+7', 'flag' => '🇰🇿'],
        ['name' => 'Senegal', 'code' => '+221', 'flag' => '🇸🇳']
    ];
    
    foreach ($defaultCountries as $country) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO countries (name, code, flag) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$country['name'], $country['code'], $country['flag']]);
        echo "Added country: {$country['name']} ✅\n";
    }
    
    // Insert default bot settings
    echo "\n⚙️ Setting up bot configuration...\n";
    $defaultSettings = [
        ['reservation_timeout_minutes', '20', 'Default reservation timeout in minutes'],
        ['maintenance_mode', '0', 'Enable maintenance mode (0=off, 1=on)'],
        ['welcome_message', '🎆 أهلاً بك في بوت خدمات الأرقام المؤقتة', 'Welcome message for new users'],
        ['minimum_balance', '1', 'Minimum balance required for using services'],
        ['daily_reward_amount', '5', 'Daily reward amount for channel subscriptions'],
        ['referral_bonus', '10', 'Bonus amount for referrals'],
        ['admin_password', 'admin123', 'Admin panel password'],
        ['bot_name', 'ELWESHAQSMS BOT', 'Bot display name'],
        ['currency_symbol', 'EGP', 'Currency symbol for pricing'],
        ['max_concurrent_reservations', '3', 'Maximum concurrent reservations per user']
    ];
    
    foreach ($defaultSettings as $setting) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO bot_settings (setting_key, setting_value, description) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute($setting);
        echo "Added setting: {$setting[0]} ✅\n";
    }
    
    // Add sample forced channels
    echo "\n📺 Adding sample forced channels...\n";
    $sampleChannels = [
        ['title' => 'قناة البوت الرسمية', 'username_or_link' => '@elweshaqsms_bot', 'channel_id' => '-1001234567890', 'reward_amount' => 5.0],
        ['title' => 'قناة العروض والتحديثات', 'username_or_link' => '@elweshaq_offers', 'channel_id' => '-1001234567891', 'reward_amount' => 3.0],
        ['title' => 'قناة الدعم الفني', 'username_or_link' => '@elweshaq_support', 'channel_id' => '-1001234567892', 'reward_amount' => 2.0]
    ];
    
    foreach ($sampleChannels as $channel) {
        $stmt = $connection->prepare("
            INSERT OR IGNORE INTO forced_channels (title, username_or_link, channel_id, reward_amount) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$channel['title'], $channel['username_or_link'], $channel['channel_id'], $channel['reward_amount']]);
        echo "Added channel: {$channel['title']} ✅\n";
    }
    
    echo "\n🎉 Comprehensive database initialization completed successfully!\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "📊 Summary:\n";
    echo "  • Total tables created: " . count($tables) . "\n";
    echo "  • Total services added: " . count($defaultServices) . "\n";
    echo "  • Total countries added: " . count($defaultCountries) . "\n";
    echo "  • Total settings configured: " . count($defaultSettings) . "\n";
    echo "  • Total channels configured: " . count($sampleChannels) . "\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "🚀 Bot is ready to use!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
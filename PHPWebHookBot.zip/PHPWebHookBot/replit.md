# replit.md

## Overview

This is a PHP-based Telegram bot application that provides SMS number services for receiving verification codes. The bot allows users to purchase temporary phone numbers from various countries and providers for receiving SMS messages from different services like WhatsApp, Telegram, and other platforms. The system has evolved from traditional API-based SMS providers to a Group ID system that monitors Telegram groups for incoming SMS codes.

Key features include:
- User balance management and transaction tracking
- Phone number reservations with automatic timeout mechanisms  
- Multi-provider integration supporting both polling and webhook modes
- Admin panel for comprehensive service and user management
- Group-based SMS code extraction system
- Channel reward mechanisms for user engagement
- Real-time SMS code retrieval and delivery to users

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Application Framework
- **Bot Framework**: Built using longman/telegram-bot PHP library for Telegram Bot API integration
- **Database Layer**: Uses direct database connections for data persistence (configured to work with various database systems)
- **Session Management**: In-memory storage for bot states and admin authentication tracking
- **Asynchronous Processing**: Event-driven architecture for handling concurrent user requests

### Group ID System Architecture
The bot has transitioned from external API providers to a Group ID-based system:
- **Service-Group Mapping**: Each service (WhatsApp, Telegram, etc.) is linked to specific Telegram groups
- **Message Monitoring**: Bot monitors registered groups for incoming SMS codes
- **Code Extraction**: Uses regex patterns to extract verification codes from group messages
- **Security Layers**: Multiple security modes including Token-only, Admin-only, and HMAC verification

### Data Models and Storage
- **User System**: Comprehensive user management with balance tracking, admin privileges, and language preferences
- **Service Management**: Hierarchical service-country-provider mapping for flexible number allocation
- **Reservation System**: Time-limited number reservations with automatic expiry (20-minute default timeout)
- **Transaction System**: Complete audit trail for all balance operations (add, deduct, purchase, reward)
- **Group Integration**: ServiceGroup model linking services to Telegram groups with security configurations
- **Message Processing**: ProviderMessage model for logging and categorizing all processed messages

### Key Architectural Decisions
- **Group-Based Code Retrieval**: Moved away from external APIs to monitoring Telegram groups directly, providing more reliable and cost-effective SMS code delivery
- **Multiple Security Modes**: Implemented flexible security system allowing different verification methods per service
- **Automatic Cleanup**: Built-in timeout mechanisms for expired reservations to prevent number hoarding
- **Multilingual Support**: Static translation system supporting Arabic and English with extensible architecture
- **Admin Authentication**: Session-based admin authentication with username/password protection

## External Dependencies

### Core PHP Dependencies
- **longman/telegram-bot**: Primary Telegram Bot API wrapper for handling bot operations and webhook processing
- **vlucas/phpdotenv**: Environment configuration management for secure credential storage
- **guzzlehttp/guzzle**: HTTP client library for making external API requests and webhook handling
- **psr/log**: PSR-3 compliant logging interfaces for structured application logging

### Infrastructure Requirements
- **Database System**: Configurable database backend (supports MySQL, PostgreSQL, SQLite)
- **Web Server**: PHP-enabled web server for webhook endpoint handling
- **Telegram Bot API**: External dependency on Telegram's Bot API services
- **Telegram Groups**: Integration with Telegram groups/channels for SMS code monitoring

### Optional Integrations
- **External SMS Providers**: Legacy support for traditional SMS API providers (configurable)
- **HMAC Security**: Optional cryptographic message authentication for enhanced security
- **Webhook Support**: Optional webhook-based message processing alongside polling mode
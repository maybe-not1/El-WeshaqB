<?php

require_once 'vendor/autoload.php';

use TelegramBot\Config;

// Load environment variables  
if (file_exists(__DIR__ . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
}

$botToken = Config::getBotToken();

if (!$botToken) {
    die("❌ BOT_TOKEN not found in environment variables\n");
}

// Get the domain from Replit environment
$domain = $_ENV['REPLIT_DEV_DOMAIN'] ?? 'localhost';
$webhookUrl = "https://{$domain}/webhook.php";

echo "🔧 Setting webhook...\n";
echo "URL: $webhookUrl\n";

$apiUrl = "https://api.telegram.org/bot{$botToken}/setWebhook";

$data = [
    'url' => $webhookUrl,
    'allowed_updates' => json_encode(['message', 'callback_query'])
];

$options = [
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query($data)
    ]
];

$result = file_get_contents($apiUrl, false, stream_context_create($options));
$response = json_decode($result, true);

if ($response && $response['ok']) {
    echo "✅ Webhook set successfully!\n";
    echo "Response: " . $result . "\n";
} else {
    echo "❌ Failed to set webhook\n";
    echo "Response: " . $result . "\n";
}

// Also set bot commands
echo "\n🤖 Setting bot commands...\n";

$commands = [
    ['command' => 'start', 'description' => '🏠 البدء'],
    ['command' => 'services', 'description' => '📱 الخدمات'],
    ['command' => 'balance', 'description' => '💰 الرصيد'],
    ['command' => 'help', 'description' => '❓ المساعدة'],
    ['command' => 'admin', 'description' => '⚙️ لوحة الإدارة']
];

$commandsUrl = "https://api.telegram.org/bot{$botToken}/setMyCommands";
$commandsData = ['commands' => json_encode($commands)];

$commandsOptions = [
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query($commandsData)
    ]
];

$commandsResult = file_get_contents($commandsUrl, false, stream_context_create($commandsOptions));
$commandsResponse = json_decode($commandsResult, true);

if ($commandsResponse && $commandsResponse['ok']) {
    echo "✅ Bot commands set successfully!\n";
} else {
    echo "❌ Failed to set bot commands\n";
    echo "Response: " . $commandsResult . "\n";
}
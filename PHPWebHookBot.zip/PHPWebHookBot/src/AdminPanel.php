<?php

namespace TelegramBot;

use TelegramBot\Models\User;
use TelegramBot\Models\Service;
use TelegramBot\Models\Number;

class AdminPanel
{
    private $userModel;
    private $serviceModel;
    private $numberModel;
    private $bot;

    public function __construct($bot)
    {
        $this->bot = $bot;
        $this->userModel = new User();
        $this->serviceModel = new Service();
        $this->numberModel = new Number();
    }

    public function showMainPanel($chatId, $lang, $messageId = null)
    {
        $text = Translation::get('welcome_user', $lang) . "\n\n";
        $text .= "🔥 " . Translation::get('admin_panel', $lang) . " 🔥\n";
        $text .= "👑 اختر القسم: 👑";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => Translation::get('admin_services', $lang), 'callback_data' => 'admin_services'],
                    ['text' => Translation::get('admin_countries', $lang), 'callback_data' => 'admin_countries']
                ],
                [
                    ['text' => Translation::get('admin_numbers', $lang), 'callback_data' => 'admin_numbers'],
                    ['text' => Translation::get('admin_groups', $lang), 'callback_data' => 'admin_groups']
                ],
                [
                    ['text' => Translation::get('admin_users', $lang), 'callback_data' => 'admin_users'],
                    ['text' => Translation::get('admin_channels', $lang), 'callback_data' => 'admin_channels']
                ],
                [
                    ['text' => Translation::get('add_balance', $lang), 'callback_data' => 'admin_add_balance'],
                    ['text' => Translation::get('deduct_balance', $lang), 'callback_data' => 'admin_deduct_balance']
                ],
                [
                    ['text' => Translation::get('private_message', $lang), 'callback_data' => 'admin_private_msg'],
                    ['text' => Translation::get('broadcast_message', $lang), 'callback_data' => 'admin_broadcast']
                ],
                [
                    ['text' => Translation::get('statistics', $lang), 'callback_data' => 'admin_stats'],
                    ['text' => Translation::get('system_settings', $lang), 'callback_data' => 'admin_settings']
                ],
                [
                    ['text' => Translation::get('data_export', $lang), 'callback_data' => 'admin_data_export'],
                    ['text' => Translation::get('forced_subscription', $lang), 'callback_data' => 'admin_forced_sub']
                ],
                [
                    ['text' => Translation::get('password_change', $lang), 'callback_data' => 'admin_change_password']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function showServicesManagement($chatId, $lang, $messageId = null)
    {
        $services = $this->serviceModel->getAll();
        
        $text = "⚙️ " . Translation::get('admin_services', $lang) . "\n\n";
        $text .= "📊 عدد الخدمات: " . count($services) . "\n\n";
        
        foreach ($services as $service) {
            $text .= ($service['emoji'] ?? '📱') . " " . $service['name'] . 
                    " - " . $service['default_price'] . " وحدة\n";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '➕ إضافة خدمة', 'callback_data' => 'admin_add_service'],
                    ['text' => '✏️ تعديل خدمة', 'callback_data' => 'admin_edit_service']
                ],
                [
                    ['text' => '🗑️ حذف خدمة', 'callback_data' => 'admin_delete_service']
                ],
                [
                    ['text' => Translation::get('back', $lang), 'callback_data' => 'admin_main']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function showStatistics($chatId, $lang, $messageId = null)
    {
        $db = Database::getInstance();
        
        // Get statistics
        $totalUsers = $db->fetchOne("SELECT COUNT(*) as count FROM users")['count'];
        $totalServices = $db->fetchOne("SELECT COUNT(*) as count FROM services WHERE active = true")['count'];
        $totalNumbers = $db->fetchOne("SELECT COUNT(*) as count FROM numbers")['count'];
        $totalReservations = $db->fetchOne("SELECT COUNT(*) as count FROM reservations")['count'];
        $activeReservations = $db->fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'waiting_code'")['count'];
        $completedReservations = $db->fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'completed'")['count'];

        $text = "📊 " . Translation::get('statistics', $lang) . "\n\n";
        $text .= "👥 إجمالي المستخدمين: {$totalUsers}\n";
        $text .= "📱 إجمالي الخدمات: {$totalServices}\n";
        $text .= "📞 إجمالي الأرقام: {$totalNumbers}\n";
        $text .= "📋 إجمالي الحجوزات: {$totalReservations}\n";
        $text .= "⏳ الحجوزات النشطة: {$activeReservations}\n";
        $text .= "✅ الحجوزات المكتملة: {$completedReservations}\n\n";
        
        // Calculate success rate
        if ($totalReservations > 0) {
            $successRate = round(($completedReservations / $totalReservations) * 100, 2);
            $text .= "📈 معدل النجاح: {$successRate}%\n";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '🔄 تحديث', 'callback_data' => 'admin_stats'],
                    ['text' => Translation::get('back', $lang), 'callback_data' => 'admin_main']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function showUsersManagement($chatId, $lang, $messageId = null)
    {
        $db = Database::getInstance();
        $users = $db->fetchAll("SELECT COUNT(*) as count, SUM(balance) as total_balance FROM users");
        $totalUsers = $users[0]['count'];
        $totalBalance = $users[0]['total_balance'] ?? 0;

        $text = "👥 " . Translation::get('admin_users', $lang) . "\n\n";
        $text .= "📊 إجمالي المستخدمين: {$totalUsers}\n";
        $text .= "💰 إجمالي الأرصدة: {$totalBalance} وحدة\n";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👤 بحث عن مستخدم', 'callback_data' => 'admin_search_user'],
                    ['text' => '💰 إدارة الأرصدة', 'callback_data' => 'admin_manage_balance']
                ],
                [
                    ['text' => '🚫 حظر مستخدم', 'callback_data' => 'admin_ban_user'],
                    ['text' => '✅ إلغاء حظر', 'callback_data' => 'admin_unban_user']
                ],
                [
                    ['text' => Translation::get('back', $lang), 'callback_data' => 'admin_main']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function showNumbersManagement($chatId, $lang, $messageId = null)
    {
        $db = Database::getInstance();
        $stats = $db->fetchAll("
            SELECT 
                status,
                COUNT(*) as count 
            FROM numbers 
            GROUP BY status
        ");

        $text = "📱 " . Translation::get('admin_numbers', $lang) . "\n\n";
        
        foreach ($stats as $stat) {
            $statusText = match($stat['status']) {
                'available' => '✅ متاح',
                'reserved' => '⏳ محجوز',
                'used' => '✔️ مستخدم',
                'deleted' => '🗑️ محذوف',
                default => $stat['status']
            };
            $text .= "{$statusText}: {$stat['count']}\n";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '➕ إضافة أرقام', 'callback_data' => 'admin_add_numbers'],
                    ['text' => '📋 رفع ملف أرقام', 'callback_data' => 'admin_upload_numbers']
                ],
                [
                    ['text' => '🔍 بحث في الأرقام', 'callback_data' => 'admin_search_numbers'],
                    ['text' => '🗑️ تنظيف الأرقام', 'callback_data' => 'admin_clean_numbers']
                ],
                [
                    ['text' => Translation::get('back', $lang), 'callback_data' => 'admin_main']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }
}
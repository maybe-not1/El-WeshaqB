<?php

namespace TelegramBot;

/**
 * Helper methods for the Comprehensive Telegram Bot
 */
trait BotHelpers
{
    public function showHelp($chatId, $lang)
    {
        $text = "❓ مساعدة البوت\n\n";
        $text .= "🤖 بوت خدمات الأرقام المؤقتة\n\n";
        $text .= "📋 الأوامر المتاحة:\n";
        $text .= "🏠 /start - العودة للرئيسية\n";
        $text .= "📱 /services - عرض الخدمات المتاحة\n";
        $text .= "💰 /balance - عرض الرصيد\n";
        $text .= "📋 /history - سجل العمليات\n";
        $text .= "❌ /cancel - إلغاء العملية الحالية\n";
        $text .= "❓ /help - عرض المساعدة\n\n";
        
        $text .= "🔧 كيفية الاستخدام:\n";
        $text .= "1. اختر الخدمة المطلوبة\n";
        $text .= "2. اختر الدولة\n";
        $text .= "3. احجز الرقم\n";
        $text .= "4. انتظر وصول كود التحقق\n";
        $text .= "5. سيتم خصم السعر تلقائياً\n\n";
        
        $text .= "🎁 للحصول على رصيد مجاني:\n";
        $text .= "اشترك في قنواتنا واضغط تحقق من الاشتراك\n\n";
        
        $text .= "📞 للدعم الفني: @support";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '🛒 الخدمات', 'callback_data' => 'services'],
                    ['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance']
                ],
                [
                    ['text' => '📞 التواصل', 'callback_data' => 'support'],
                    ['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']
                ]
            ]
        ];

        $this->sendMessage($chatId, $text, $keyboard);
    }

    public function showUserHistory($chatId, $user, $lang, $messageId = null)
    {
        $reservations = $this->reservationModel->getUserHistory($user['id'], 10);
        $transactions = $this->transactionModel->getUserHistory($user['id'], 10);
        
        $text = "📋 سجل العمليات\n\n";
        
        if (!empty($reservations)) {
            $text .= "📱 آخر الحجوزات:\n";
            foreach (array_slice($reservations, 0, 5) as $reservation) {
                $status = $this->getStatusEmoji($reservation['status']);
                $date = date('d/m H:i', strtotime($reservation['created_at']));
                $text .= "{$status} {$reservation['service_name']} - {$reservation['phone_number']} ({$date})\n";
            }
            $text .= "\n";
        }
        
        if (!empty($transactions)) {
            $text .= "💰 آخر المعاملات:\n";
            foreach (array_slice($transactions, 0, 5) as $transaction) {
                $type = $this->getTransactionTypeEmoji($transaction['type']);
                $date = date('d/m H:i', strtotime($transaction['created_at']));
                $amount = $transaction['amount'];
                $text .= "{$type} {$amount} جنيه - {$transaction['reason']} ({$date})\n";
            }
        }
        
        if (empty($reservations) && empty($transactions)) {
            $text .= "لا توجد عمليات سابقة";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📱 حجوزاتي النشطة', 'callback_data' => 'active_reservations'],
                    ['text' => '💰 سجل المعاملات', 'callback_data' => 'transaction_history']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'main_menu']
                ]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function checkUserSubscriptions($chatId, $user, $lang, $messageId)
    {
        $channels = $this->forcedChannelModel->getAll();
        $totalReward = 0;
        $subscribedCount = 0;
        $rewardText = "";
        
        foreach ($channels as $channel) {
            if ($this->forcedChannelModel->canReceiveReward($user['id'], $channel['id'], $channel['frequency'])) {
                // Simulate subscription check (in real implementation, use getChatMember API)
                $isSubscribed = true; // Placeholder
                
                if ($isSubscribed) {
                    // Record reward
                    $this->forcedChannelModel->recordReward($user['id'], $channel['id'], $channel['reward_amount']);
                    $this->transactionModel->create(
                        $user['id'], 
                        'reward', 
                        $channel['reward_amount'], 
                        "مكافأة الاشتراك في {$channel['title']}"
                    );
                    
                    // Update user balance
                    $this->userModel->addBalance($user['id'], $channel['reward_amount']);
                    
                    $totalReward += $channel['reward_amount'];
                    $subscribedCount++;
                    $rewardText .= "✅ {$channel['title']}: +{$channel['reward_amount']} جنيه\n";
                }
            }
        }
        
        if ($totalReward > 0) {
            $text = "🎉 تهانينا!\n\n";
            $text .= $rewardText;
            $text .= "\n💰 إجمالي المكافأة: {$totalReward} جنيه\n";
            $text .= "✅ تم إضافة المكافأة لرصيدك بنجاح!";
            
            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '💰 عرض الرصيد', 'callback_data' => 'balance'],
                        ['text' => '🛒 استخدام الخدمات', 'callback_data' => 'services']
                    ],
                    [
                        ['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']
                    ]
                ]
            ];
        } else {
            $text = "❌ لم يتم العثور على اشتراكات جديدة\n\n";
            $text .= "تأكد من:\n";
            $text .= "• الاشتراك في جميع القنوات\n";
            $text .= "• عدم مغادرة أي قناة\n";
            $text .= "• انتظار دقيقة ثم المحاولة مرة أخرى";
            
            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '🔄 إعادة المحاولة', 'callback_data' => 'check_subscriptions'],
                        ['text' => '📺 عرض القنوات', 'callback_data' => 'free_balance']
                    ],
                    [
                        ['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']
                    ]
                ]
            ];
        }
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }

    public function handleServiceSelection($chatId, $serviceId, $user, $lang, $messageId)
    {
        $this->serviceSelection->handleServiceSelection($chatId, $serviceId, $user, $lang, $messageId);
    }

    public function handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $this->serviceSelection->handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId);
    }

    public function handleNumberReservation($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $this->serviceSelection->handleNumberReservation($chatId, $serviceId, $countryCode, $user, $lang, $messageId);
    }

    public function handleChangeNumber($chatId, $reservationId, $user, $lang, $messageId)
    {
        $reservation = $this->reservationModel->findById($reservationId);
        
        if (!$reservation || $reservation['user_id'] != $user['id']) {
            $this->answerCallbackQuery($callbackQuery['id'], "❌ حجز غير صالح");
            return;
        }

        // Cancel current reservation and release number
        $this->reservationModel->cancel($reservationId);
        $this->numberModel->releaseNumber($reservation['number_id']);
        
        // Redirect to country selection for same service
        $this->handleServiceSelection($chatId, $reservation['service_id'], $user, $lang, $messageId);
    }

    public function handleCancelReservation($chatId, $reservationId, $user, $lang, $messageId)
    {
        $reservation = $this->reservationModel->findById($reservationId);
        
        if (!$reservation || $reservation['user_id'] != $user['id']) {
            $this->answerCallbackQuery($callbackQuery['id'], "❌ حجز غير صالح");
            return;
        }

        // Cancel reservation and release number
        $this->reservationModel->cancel($reservationId);
        $this->numberModel->releaseNumber($reservation['number_id']);
        
        $text = "✅ تم إلغاء الحجز بنجاح\n\n";
        $text .= "تم تحرير الرقم وإلغاء الحجز";
        
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '🛒 اختيار خدمة أخرى', 'callback_data' => 'services'],
                    ['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']
                ]
            ]
        ];
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }

    public function handleAdminCallback($data, $chatId, $userId, $lang, $messageId)
    {
        $this->adminPanel->handleCallback($data, $chatId, $userId, $lang, $messageId);
    }

    private function getStatusEmoji($status)
    {
        switch ($status) {
            case 'completed': return '✅';
            case 'waiting_code': return '⏳';
            case 'expired': return '⏰';
            case 'cancelled': return '❌';
            default: return '❓';
        }
    }

    private function getTransactionTypeEmoji($type)
    {
        switch ($type) {
            case 'add': return '💰';
            case 'deduct': return '💸';
            case 'purchase': return '🛒';
            case 'reward': return '🎁';
            default: return '💳';
        }
    }
}
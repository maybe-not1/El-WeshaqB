<?php

namespace TelegramBot;

use TelegramBot\Models\User;
use TelegramBot\Models\Service;
use TelegramBot\Models\Number;
use TelegramBot\Models\ForcedChannel;
use TelegramBot\Models\Transaction;
use TelegramBot\Models\Reservation;

class ComprehensiveAdminPanel
{
    private $bot;
    private $userModel;
    private $serviceModel;
    private $numberModel;
    private $forcedChannelModel;
    private $transactionModel;
    private $reservationModel;

    public function __construct($bot)
    {
        $this->bot = $bot;
        $this->userModel = new User();
        $this->serviceModel = new Service();
        $this->numberModel = new Number();
        $this->forcedChannelModel = new ForcedChannel();
        $this->transactionModel = new Transaction();
        $this->reservationModel = new Reservation();
    }

    public function showMainPanel($chatId, $lang, $messageId = null)
    {
        $text = "🔥 لوحة الإدارة 🔥\n\n";
        $text .= "👑 اختر القسم المطلوب:";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📱 إدارة الخدمات', 'callback_data' => 'admin_services'],
                    ['text' => '🌍 إدارة الدول', 'callback_data' => 'admin_countries']
                ],
                [
                    ['text' => '📞 إدارة الأرقام', 'callback_data' => 'admin_numbers'],
                    ['text' => '📺 إدارة القنوات', 'callback_data' => 'admin_channels']
                ],
                [
                    ['text' => '👥 إدارة المستخدمين', 'callback_data' => 'admin_users'],
                    ['text' => '💰 إدارة الرصيد', 'callback_data' => 'admin_balance']
                ],
                [
                    ['text' => '📊 الإحصائيات', 'callback_data' => 'admin_stats'],
                    ['text' => '⚙️ الإعدادات', 'callback_data' => 'admin_settings']
                ],
                [
                    ['text' => '📢 الرسائل', 'callback_data' => 'admin_messages'],
                    ['text' => '📄 تصدير البيانات', 'callback_data' => 'admin_export']
                ],
                [
                    ['text' => '🔧 وضع الصيانة', 'callback_data' => 'admin_maintenance']
                ]
            ]
        ];

        if ($messageId) {
            return $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            return $this->bot->sendMessage($chatId, $text, $keyboard);
        }
    }

    public function handleCallback($data, $chatId, $userId, $lang, $messageId)
    {
        switch ($data) {
            case 'admin_services':
                $this->showServicesManagement($chatId, $messageId);
                break;
            case 'admin_numbers':
                $this->showNumbersManagement($chatId, $messageId);
                break;
            case 'admin_channels':
                $this->showChannelsManagement($chatId, $messageId);
                break;
            case 'admin_users':
                $this->showUsersManagement($chatId, $messageId);
                break;
            case 'admin_stats':
                $this->showStatistics($chatId, $messageId);
                break;
            case 'admin_balance':
                $this->showBalanceManagement($chatId, $messageId);
                break;
            case 'admin_settings':
                $this->showSettings($chatId, $messageId);
                break;
            default:
                $this->showMainPanel($chatId, $lang, $messageId);
        }
    }

    private function showServicesManagement($chatId, $messageId)
    {
        $services = $this->serviceModel->getAll();
        
        $text = "📱 إدارة الخدمات\n\n";
        $text .= "📊 إجمالي الخدمات: " . count($services) . "\n\n";
        
        foreach ($services as $service) {
            $status = $service['active'] ? '✅' : '❌';
            $text .= "{$status} {$service['emoji']} {$service['name']} - {$service['default_price']} جنيه\n";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '➕ إضافة خدمة', 'callback_data' => 'admin_add_service'],
                    ['text' => '❌ حذف خدمة', 'callback_data' => 'admin_delete_service']
                ],
                [
                    ['text' => '✏️ تعديل خدمة', 'callback_data' => 'admin_edit_service'],
                    ['text' => '🔄 تفعيل/إلغاء', 'callback_data' => 'admin_toggle_service']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showNumbersManagement($chatId, $messageId)
    {
        $stats = $this->numberModel->getStats();
        
        $text = "📞 إدارة الأرقام\n\n";
        $text .= "📊 الإحصائيات:\n";
        $text .= "🟢 متاحة: " . ($stats['available'] ?? 0) . "\n";
        $text .= "🟡 محجوزة: " . ($stats['reserved'] ?? 0) . "\n";
        $text .= "🔴 مستخدمة: " . ($stats['used'] ?? 0) . "\n";
        $text .= "📊 الإجمالي: " . ($stats['total'] ?? 0);

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📄 رفع ملف أرقام', 'callback_data' => 'admin_upload_numbers'],
                    ['text' => '➕ إضافة رقم يدوي', 'callback_data' => 'admin_add_number']
                ],
                [
                    ['text' => '📋 عرض الأرقام', 'callback_data' => 'admin_view_numbers'],
                    ['text' => '🗑️ حذف رقم', 'callback_data' => 'admin_delete_number']
                ],
                [
                    ['text' => '🧹 تنظيف الأرقام', 'callback_data' => 'admin_cleanup_numbers']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showStatistics($chatId, $messageId)
    {
        $userStats = $this->userModel->getStats();
        $reservationStats = $this->reservationModel->getStats();
        $transactionStats = $this->transactionModel->getTotalStats();

        $text = "📊 إحصائيات شاملة\n\n";
        
        $text .= "👥 المستخدمين:\n";
        $text .= "• إجمالي المستخدمين: " . ($userStats['total'] ?? 0) . "\n";
        $text .= "• المشرفين: " . ($userStats['admins'] ?? 0) . "\n";
        $text .= "• محظورين: " . ($userStats['banned'] ?? 0) . "\n\n";
        
        $text .= "📱 الحجوزات:\n";
        $text .= "• إجمالي: " . ($reservationStats['total'] ?? 0) . "\n";
        $text .= "• مكتملة: " . ($reservationStats['completed'] ?? 0) . "\n";
        $text .= "• نشطة: " . ($reservationStats['active'] ?? 0) . "\n";
        $text .= "• منتهية: " . ($reservationStats['expired'] ?? 0) . "\n\n";
        
        $text .= "💰 المعاملات:\n";
        $text .= "• إجمالي الإيداعات: " . ($transactionStats['total_deposits'] ?? 0) . " جنيه\n";
        $text .= "• إجمالي المشتريات: " . ($transactionStats['total_purchases'] ?? 0) . " جنيه\n";
        $text .= "• إجمالي المكافآت: " . ($transactionStats['total_rewards'] ?? 0) . " جنيه";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📈 تقرير يومي', 'callback_data' => 'admin_daily_report'],
                    ['text' => '📊 تقرير شهري', 'callback_data' => 'admin_monthly_report']
                ],
                [
                    ['text' => '💹 أفضل الخدمات', 'callback_data' => 'admin_top_services']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showBalanceManagement($chatId, $messageId)
    {
        $text = "💰 إدارة الرصيد\n\n";
        $text .= "اختر العملية المطلوبة:";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '➕ إضافة رصيد', 'callback_data' => 'admin_add_balance_user'],
                    ['text' => '➖ خصم رصيد', 'callback_data' => 'admin_deduct_balance_user']
                ],
                [
                    ['text' => '👤 البحث عن مستخدم', 'callback_data' => 'admin_search_user'],
                    ['text' => '📋 عرض الرصيد', 'callback_data' => 'admin_view_balance']
                ],
                [
                    ['text' => '📊 تقرير الأرصدة', 'callback_data' => 'admin_balance_report']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showChannelsManagement($chatId, $messageId)
    {
        $channels = $this->forcedChannelModel->getAll();
        
        $text = "📺 إدارة القنوات الإجبارية\n\n";
        $text .= "📊 إجمالي القنوات: " . count($channels) . "\n\n";
        
        foreach ($channels as $channel) {
            $status = $channel['active'] ? '✅' : '❌';
            $text .= "{$status} {$channel['title']} (+{$channel['reward_amount']} جنيه)\n";
        }

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '➕ إضافة قناة', 'callback_data' => 'admin_add_channel'],
                    ['text' => '❌ حذف قناة', 'callback_data' => 'admin_delete_channel']
                ],
                [
                    ['text' => '✏️ تعديل قناة', 'callback_data' => 'admin_edit_channel'],
                    ['text' => '🔄 تفعيل/إلغاء', 'callback_data' => 'admin_toggle_channel']
                ],
                [
                    ['text' => '📊 إحصائيات القنوات', 'callback_data' => 'admin_channel_stats']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showUsersManagement($chatId, $messageId)
    {
        $userStats = $this->userModel->getStats();
        
        $text = "👥 إدارة المستخدمين\n\n";
        $text .= "📊 الإحصائيات:\n";
        $text .= "• إجمالي المستخدمين: " . ($userStats['total'] ?? 0) . "\n";
        $text .= "• المشرفين: " . ($userStats['admins'] ?? 0) . "\n";
        $text .= "• محظورين: " . ($userStats['banned'] ?? 0) . "\n";
        $text .= "• نشطين اليوم: " . ($userStats['active_today'] ?? 0);

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👤 البحث عن مستخدم', 'callback_data' => 'admin_search_user'],
                    ['text' => '👥 قائمة المستخدمين', 'callback_data' => 'admin_users_list']
                ],
                [
                    ['text' => '👑 إضافة مشرف', 'callback_data' => 'admin_add_admin'],
                    ['text' => '🚫 حظر مستخدم', 'callback_data' => 'admin_ban_user']
                ],
                [
                    ['text' => '📈 المستخدمين النشطين', 'callback_data' => 'admin_active_users']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function showSettings($chatId, $messageId)
    {
        $text = "⚙️ إعدادات البوت\n\n";
        $text .= "اختر الإعداد المطلوب تعديله:";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '⏰ مهلة الحجز', 'callback_data' => 'admin_set_timeout'],
                    ['text' => '🔧 وضع الصيانة', 'callback_data' => 'admin_maintenance']
                ],
                [
                    ['text' => '💰 الحد الأدنى للرصيد', 'callback_data' => 'admin_min_balance'],
                    ['text' => '🎁 مكافآت القنوات', 'callback_data' => 'admin_reward_amount']
                ],
                [
                    ['text' => '📝 رسالة الترحيب', 'callback_data' => 'admin_welcome_msg'],
                    ['text' => '🔑 كلمة مرور الأدمن', 'callback_data' => 'admin_password']
                ],
                [
                    ['text' => '📊 الحد الأقصى للحجوزات', 'callback_data' => 'admin_max_reservations']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'admin_main']
                ]
            ]
        ];

        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }
}
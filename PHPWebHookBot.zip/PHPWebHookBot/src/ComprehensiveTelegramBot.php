<?php

namespace TelegramBot;

use TelegramBot\Models\User;
use TelegramBot\Models\Service;
use TelegramBot\Models\Number;
use TelegramBot\Models\Reservation;
use TelegramBot\Models\UserState;
use TelegramBot\Models\ForcedChannel;
use TelegramBot\Models\Transaction;

class ComprehensiveTelegramBot
{
    use BotHelpers;
    private $apiUrl;
    private $userModel;
    private $serviceModel;
    private $numberModel;
    private $reservationModel;
    private $userStateModel;
    private $forcedChannelModel;
    private $transactionModel;
    private $adminPanel;
    private $maintenanceMode = false;

    public function __construct()
    {
        $token = Config::getBotToken();
        if (!$token) {
            throw new \Exception('BOT_TOKEN not found in environment');
        }
        
        $this->apiUrl = "https://api.telegram.org/bot{$token}";
        $this->userModel = new User();
        $this->serviceModel = new Service();
        $this->numberModel = new Number();
        $this->reservationModel = new Reservation();
        $this->userStateModel = new UserState();
        $this->forcedChannelModel = new ForcedChannel();
        $this->transactionModel = new Transaction();
        $this->adminPanel = new ComprehensiveAdminPanel($this);
        $this->loadMaintenanceMode();
    }

    public function handleUpdate($update)
    {
        try {
            // Check maintenance mode first
            if ($this->maintenanceMode) {
                $userId = isset($update['message']) ? $update['message']['from']['id'] : 
                         (isset($update['callback_query']) ? $update['callback_query']['from']['id'] : null);
                
                // Allow admin even in maintenance mode
                if ($userId && !$this->userModel->isAdmin($userId)) {
                    $chatId = isset($update['message']) ? $update['message']['chat']['id'] : 
                             (isset($update['callback_query']) ? $update['callback_query']['message']['chat']['id'] : null);
                    
                    if ($chatId) {
                        $this->sendMaintenanceMessage($chatId);
                        return;
                    }
                }
            }
            
            if (isset($update['message'])) {
                $this->handleMessage($update['message']);
            } elseif (isset($update['callback_query'])) {
                $this->handleCallbackQuery($update['callback_query']);
            }
        } catch (\Exception $e) {
            error_log('Bot error: ' . $e->getMessage());
        }
    }

    private function handleMessage($message)
    {
        $chatId = $message['chat']['id'];
        $userId = $message['from']['id'];
        $text = $message['text'] ?? '';
        $username = $message['from']['username'] ?? null;
        $firstName = $message['from']['first_name'] ?? null;
        $lastName = $message['from']['last_name'] ?? null;

        // Get or create user
        $user = $this->userModel->getOrCreate($userId, $username, $firstName, $lastName);
        $lang = $user['language_code'] ?? 'ar';

        // Get user state
        $userState = $this->userStateModel->getState($user['id']);

        // Check for maintenance mode
        if ($this->isMaintenanceMode() && !$this->userModel->isAdmin($userId)) {
            $this->sendMessage($chatId, "⚠️ البوت قيد الصيانة حالياً، يرجى المحاولة لاحقاً");
            return;
        }

        // Handle commands
        if ($text === '/start') {
            $this->userStateModel->setState($user['id'], 'idle');
            $this->handleStart($chatId, $lang);
        } elseif ($text === '/balance') {
            $this->handleBalance($chatId, $user, $lang);
        } elseif ($text === '/services') {
            $this->handleServices($chatId, $lang);
        } elseif ($text === '/admin' && $this->userModel->isAdmin($userId)) {
            $this->adminPanel->showMainPanel($chatId, $lang);
        } elseif ($text === '/help') {
            $this->showHelp($chatId, $lang);
        } elseif ($text === '/history') {
            $this->showUserHistory($chatId, $user, $lang);
        } elseif ($text === '/cancel') {
            $this->userStateModel->setState($user['id'], 'idle');
            $this->handleStart($chatId, $lang);
        } else {
            // Handle state-based inputs or show main menu
            $this->handleMainMenu($chatId, $lang);
        }
    }

    private function handleCallbackQuery($callbackQuery)
    {
        $chatId = $callbackQuery['message']['chat']['id'];
        $userId = $callbackQuery['from']['id'];
        $data = $callbackQuery['data'];
        $messageId = $callbackQuery['message']['message_id'];

        $user = $this->userModel->findByTelegramId($userId);
        $lang = $user['language_code'] ?? 'ar';

        // Answer callback query
        $this->answerCallbackQuery($callbackQuery['id']);

        if ($data === 'main_menu') {
            $this->userStateModel->setState($user['id'], 'idle');
            $this->handleMainMenu($chatId, $lang, $messageId);
        } elseif ($data === 'services') {
            $this->handleServices($chatId, $lang, $messageId);
        } elseif ($data === 'balance') {
            $this->handleBalance($chatId, $user, $lang, $messageId);
        } elseif ($data === 'free_balance') {
            $this->handleFreeBalance($chatId, $user, $lang, $messageId);
        } elseif ($data === 'history') {
            $this->showUserHistory($chatId, $user, $lang, $messageId);
        } elseif ($data === 'check_subscriptions') {
            $this->checkUserSubscriptions($chatId, $user, $lang, $messageId);
        } elseif ($data === 'stats') {
            $this->handleStats($chatId, $user, $lang, $messageId);
        } elseif ($data === 'help') {
            $this->handleHelp($chatId, $lang, $messageId);
        } elseif ($data === 'support') {
            $this->handleSupport($chatId, $lang, $messageId);
        } elseif ($data === 'language') {
            $this->handleLanguage($chatId, $lang, $messageId);
        } elseif ($data === 'active_reservations') {
            $this->handleActiveReservations($chatId, $user, $lang, $messageId);
        } elseif (strpos($data, 'lang_') === 0) {
            $newLang = str_replace('lang_', '', $data);
            $this->handleLanguageChange($chatId, $user, $newLang, $messageId);
        } elseif (strpos($data, 'service_') === 0) {
            $serviceId = (int) str_replace('service_', '', $data);
            $this->handleServiceSelection($chatId, $serviceId, $user, $lang, $messageId);
        } elseif (strpos($data, 'country_') === 0) {
            $parts = explode('_', $data);
            $serviceId = (int) $parts[1];
            $countryCode = $parts[2];
            $this->handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId);
        } elseif (strpos($data, 'reserve_') === 0) {
            $parts = explode('_', $data);
            $serviceId = (int) $parts[1];
            $countryCode = $parts[2];
            $this->handleNumberReservation($chatId, $serviceId, $countryCode, $user, $lang, $messageId);
        } elseif (strpos($data, 'change_number_') === 0) {
            $reservationId = (int) str_replace('change_number_', '', $data);
            $this->handleChangeNumber($chatId, $reservationId, $user, $lang, $messageId);
        } elseif (strpos($data, 'cancel_reservation_') === 0) {
            $reservationId = (int) str_replace('cancel_reservation_', '', $data);
            $this->handleCancelReservation($chatId, $reservationId, $user, $lang, $messageId);
        } elseif (strpos($data, 'admin_') === 0 && $this->userModel->isAdmin($userId)) {
            $this->adminPanel->handleCallback($data, $chatId, $userId, $lang, $messageId);
        }
    }

    private function handleStart($chatId, $lang)
    {
        // Welcome message similar to the original Python version
        $text = "🔥 مرحباً بك في بوت الأرقام الوهمية المجاني! 🔥\n\n";
        $text .= "🎯 احصل على أرقام وهمية لتفعيل حساباتك على:\n";
        $text .= "━━━━━━━━━━━━━━━━━━━\n";
        $text .= "💬 واتساب  •  ✈️ تليجرام  •  📷 انستجرام\n";
        $text .= "📘 فيسبوك  •  🐦 تويتر  •  🎵 تيك توك\n";
        $text .= "🌐 جوجل  •  👻 سناب شات  •  وأكثر!\n";
        $text .= "━━━━━━━━━━━━━━━━━━━\n\n";
        
        $text .= "✨ المميزات الحصرية:\n";
        $text .= "🚀 استلام فوري للأكواد (أقل من دقيقة)\n";
        $text .= "🛡️ أمان مضمون 100% وخصوصية تامة\n";
        $text .= "💎 جودة عالية وأرقام حقيقية\n";
        $text .= "🌍 دعم أكثر من 50 دولة\n";
        $text .= "💰 أسعار منافسة تبدأ من 2.5 جنيه\n";
        $text .= "🎁 رصيد مجاني يومياً!\n\n";
        
        $text .= "🎮 اختر الخدمة المطلوبة:";
        
        $this->sendMessage($chatId, $text, $this->getMainMenuKeyboard($lang));
    }

    private function handleMainMenu($chatId, $lang, $messageId = null)
    {
        $text = "🏠 القائمة الرئيسية\n\n🌟 اختر ما تريد فعله:";
        $keyboard = $this->getMainMenuKeyboard($lang);
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function getMainMenuKeyboard($lang)
    {
        return [
            'inline_keyboard' => [
                [
                    ['text' => '🛒 اختيار الخدمة', 'callback_data' => 'services'],
                    ['text' => '💰 رصيدي الحالي', 'callback_data' => 'balance']
                ],
                [
                    ['text' => '🎁 رصيد مجاني', 'callback_data' => 'free_balance'],
                    ['text' => '📊 إحصائياتي', 'callback_data' => 'stats']
                ],
                [
                    ['text' => '📋 سجل العمليات', 'callback_data' => 'history'],
                    ['text' => '🔔 حجوزاتي النشطة', 'callback_data' => 'active_reservations']
                ],
                [
                    ['text' => '🌍 تغيير اللغة', 'callback_data' => 'language'],
                    ['text' => '❓ كيفية الاستخدام', 'callback_data' => 'help']
                ],
                [
                    ['text' => '📞 دعم فني', 'callback_data' => 'support']
                ]
            ]
        ];
    }

    private function handleServices($chatId, $lang, $messageId = null)
    {
        $services = $this->serviceModel->getActive();
        
        if (empty($services)) {
            $text = "❌ عذراً، لا توجد خدمات متاحة في الوقت الحالي\n\n";
            $text .= "🔄 يرجى المحاولة مرة أخرى لاحقاً أو التواصل مع الدعم الفني";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '📞 دعم فني', 'callback_data' => 'support']],
                    [['text' => '🔙 رجوع للرئيسية', 'callback_data' => 'main_menu']]
                ]
            ];
        } else {
            $text = "🛒 اختر الخدمة المطلوبة:\n";
            $text .= "━━━━━━━━━━━━━━━━━━━━━\n\n";
            $text .= "⭐ الخدمات المتاحة حالياً (" . count($services) . "):\n\n";
            
            $keyboard = ['inline_keyboard' => []];
            
            // Group services by popularity/type
            $popularServices = [];
            $otherServices = [];
            
            foreach ($services as $service) {
                $serviceText = $service['emoji'] . ' ' . $service['name'] . ' - ' . $service['default_price'] . ' ج.م';
                
                // Popular services (WhatsApp, Telegram, Instagram)
                if (in_array($service['name'], ['WhatsApp', 'Telegram', 'Instagram'])) {
                    $popularServices[] = [
                        'text' => $serviceText,
                        'callback_data' => 'service_' . $service['id']
                    ];
                } else {
                    $otherServices[] = [
                        'text' => $serviceText,
                        'callback_data' => 'service_' . $service['id']
                    ];
                }
            }
            
            // Add popular services first (one per row for prominence)
            foreach ($popularServices as $service) {
                $keyboard['inline_keyboard'][] = [$service];
            }
            
            // Add other services in pairs
            $row = [];
            foreach ($otherServices as $index => $service) {
                $row[] = $service;
                
                // Two services per row
                if (($index + 1) % 2 === 0 || $index === count($otherServices) - 1) {
                    $keyboard['inline_keyboard'][] = $row;
                    $row = [];
                }
            }
            
            $keyboard['inline_keyboard'][] = [
                ['text' => '🔄 تحديث القائمة', 'callback_data' => 'services'],
                ['text' => '🔙 رجوع', 'callback_data' => 'main_menu']
            ];
        }
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleBalance($chatId, $user, $lang, $messageId = null)
    {
        $stats = $this->transactionModel->getUserStats($user['id']);
        
        $text = "💰 معلومات الرصيد:\n\n";
        $text .= "💳 الرصيد الحالي: {$user['balance']} جنيه\n";
        $text .= "📈 إجمالي الإيداعات: " . ($stats['total_added'] ?? 0) . " جنيه\n";
        $text .= "📉 إجمالي المصروفات: " . ($stats['total_spent'] ?? 0) . " جنيه\n";
        $text .= "🎁 إجمالي المكافآت: " . ($stats['total_rewards'] ?? 0) . " جنيه\n";
        $text .= "🔢 عدد المعاملات: " . ($stats['total_transactions'] ?? 0);
        
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance'],
                    ['text' => '📋 سجل المعاملات', 'callback_data' => 'history']
                ],
                [
                    ['text' => '🔙 رجوع', 'callback_data' => 'main_menu']
                ]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleFreeBalance($chatId, $user, $lang, $messageId = null)
    {
        $channels = $this->forcedChannelModel->getAll();
        
        if (empty($channels)) {
            $text = "❌ لا توجد قنوات للاشتراك حالياً";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔙 رجوع', 'callback_data' => 'balance']]
                ]
            ];
        } else {
            $text = "🎁 احصل على رصيد مجاني!\n\n";
            $text .= "اشترك في القنوات التالية للحصول على رصيد مجاني:\n\n";
            
            $keyboard = ['inline_keyboard' => []];
            $totalReward = 0;
            
            foreach ($channels as $channel) {
                if ($this->forcedChannelModel->canReceiveReward($user['id'], $channel['id'], $channel['frequency'])) {
                    $text .= "📺 {$channel['title']}: +{$channel['reward_amount']} جنيه\n";
                    $totalReward += $channel['reward_amount'];
                    
                    $keyboard['inline_keyboard'][] = [
                        ['text' => "📺 {$channel['title']}", 'url' => "https://t.me/" . ltrim($channel['username_or_link'], '@')]
                    ];
                }
            }
            
            if ($totalReward > 0) {
                $text .= "\n💰 إجمالي الرصيد المتاح: {$totalReward} جنيه";
                $keyboard['inline_keyboard'][] = [
                    ['text' => '✅ تحقق من الاشتراك', 'callback_data' => 'check_subscriptions']
                ];
            } else {
                $text .= "\n✅ لقد حصلت على جميع المكافآت المتاحة!";
            }
            
            $keyboard['inline_keyboard'][] = [
                ['text' => '🔙 رجوع', 'callback_data' => 'balance']
            ];
        }
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleStats($chatId, $user, $lang, $messageId = null)
    {
        $userCount = $this->userModel->getTotalUsers();
        $serviceCount = count($this->serviceModel->getActive());
        $reservationCount = $this->reservationModel->getUserReservations($user['id']);
        
        $text = "📊 إحصائيات البوت\n\n";
        $text .= "👥 إجمالي المستخدمين: {$userCount}\n";
        $text .= "📱 الخدمات المتاحة: {$serviceCount}\n";
        $text .= "🔢 حجوزاتك: " . count($reservationCount) . "\n";
        $text .= "💰 رصيدك: {$user['balance']} جنيه";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '🔙 رجوع', 'callback_data' => 'main_menu']]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }
    
    private function handleHelp($chatId, $lang, $messageId = null)
    {
        $text = "❓ مساعدة البوت\n\n";
        $text .= "🤖 كيفية استخدام البوت:\n\n";
        $text .= "1️⃣ اختر الخدمة المطلوبة من قائمة الخدمات\n";
        $text .= "2️⃣ اختر الدولة (إن وجدت)\n";
        $text .= "3️⃣ سيتم حجز رقم لك لمدة 20 دقيقة\n";
        $text .= "4️⃣ استخدم الرقم للتسجيل في الخدمة\n";
        $text .= "5️⃣ ستصلك رسالة التحقق تلقائياً\n\n";
        $text .= "💰 لشحن الرصيد: تواصل مع الدعم\n";
        $text .= "🆓 للحصول على رصيد مجاني: اشترك في القنوات";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📞 التواصل', 'callback_data' => 'support']],
                [['text' => '🔙 رجوع', 'callback_data' => 'main_menu']]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }
    
    private function handleSupport($chatId, $lang, $messageId = null)
    {
        $text = "📞 التواصل والدعم\n\n";
        $text .= "للمساعدة أو الاستفسارات:\n\n";
        $text .= "💬 المحادثة المباشرة: @support\n";
        $text .= "📧 البريد الإلكتروني: support@example.com\n";
        $text .= "⏰ ساعات العمل: 24/7\n\n";
        $text .= "🔍 الأسئلة الشائعة:\n";
        $text .= "• كيف أشحن رصيدي؟\n";
        $text .= "• ماذا لو لم أستلم الكود؟\n";
        $text .= "• كيف أسترد الأموال؟";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '💬 محادثة مباشرة', 'url' => 'https://t.me/support']],
                [['text' => '❓ المساعدة', 'callback_data' => 'help']],
                [['text' => '🔙 رجوع', 'callback_data' => 'main_menu']]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleServiceSelection($chatId, $serviceId, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        if (!$service) {
            $this->editMessage($chatId, $messageId, "❌ خدمة غير موجودة", [
                'inline_keyboard' => [[['text' => '🔙 رجوع', 'callback_data' => 'services']]]
            ]);
            return;
        }
        
        // Check user balance
        if ($user['balance'] < $service['default_price']) {
            $text = "💰 رصيد غير كافي! تحتاج إلى {$service['default_price']} جنيه";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance']],
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }
        
        // Show service countries or direct purchase
        $countries = $this->serviceModel->getServiceCountries($serviceId);
        
        if (empty($countries)) {
            // No specific countries - show general purchase option
            $text = "📱 {$service['emoji']} {$service['name']}\n\n";
            $text .= "💰 السعر: {$service['default_price']} جنيه\n";
            $text .= "📄 الوصف: {$service['description']}\n\n";
            $text .= "✅ هل تريد حجز رقم لهذه الخدمة؟";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '✅ نعم، احجز رقم', 'callback_data' => "reserve_{$serviceId}_"]],
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ];
        } else {
            // Show available countries
            $text = "🌍 اختر الدولة لخدمة {$service['name']}:\n\n";
            $keyboard = ['inline_keyboard' => []];
            
            $row = [];
            foreach ($countries as $index => $country) {
                $row[] = [
                    'text' => $country['flag'] . ' ' . $country['country_name'],
                    'callback_data' => "country_{$serviceId}_{$country['country_code']}"
                ];
                
                // Two countries per row
                if (($index + 1) % 2 === 0 || $index === count($countries) - 1) {
                    $keyboard['inline_keyboard'][] = $row;
                    $row = [];
                }
            }
            
            $keyboard['inline_keyboard'][] = [
                ['text' => '🔙 رجوع', 'callback_data' => 'services']
            ];
        }
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }
    
    private function handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        if (!$service) return;
        
        // Check balance again
        if ($user['balance'] < $service['default_price']) {
            $text = "💰 رصيد غير كافي! تحتاج إلى {$service['default_price']} جنيه";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance']],
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }
        
        // Show confirmation for country selection
        $country = null;
        $countries = $this->serviceModel->getServiceCountries($serviceId);
        foreach ($countries as $c) {
            if ($c['country_code'] === $countryCode) {
                $country = $c;
                break;
            }
        }
        
        $text = "📱 {$service['emoji']} {$service['name']}\n";
        $text .= "🌍 الدولة: " . ($country ? $country['flag'] . ' ' . $country['country_name'] : $countryCode) . "\n";
        $text .= "💰 السعر: {$service['default_price']} جنيه\n\n";
        $text .= "✅ هل تريد حجز رقم لهذه الخدمة؟";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '✅ نعم، احجز رقم', 'callback_data' => "reserve_{$serviceId}_{$countryCode}"]],
                [['text' => '🔙 رجوع', 'callback_data' => "service_{$serviceId}"]]
            ]
        ];
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }
    
    private function handleNumberReservation($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        if (!$service) return;
        
        // Final balance check
        if ($user['balance'] < $service['default_price']) {
            $text = "💰 رصيد غير كافي! تحتاج إلى {$service['default_price']} جنيه";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance']],
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }
        
        // For now, show a message that the feature is being developed
        $text = "🔧 عذراً، هذه الخدمة قيد التطوير\n\n";
        $text .= "🔍 نحن نعمل على تحسين هذه الخدمة لتقديم أفضل تجربة\n";
        $text .= "🔔 سيتم إشعارك عند توفرها";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📞 التواصل', 'callback_data' => 'support']],
                [['text' => '🔙 رجوع', 'callback_data' => 'services']]
            ]
        ];
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }
    
    private function handleLanguage($chatId, $lang, $messageId = null)
    {
        $text = "🌍 اختر اللغة المفضلة:\n\n";
        $text .= "🇪🇬 للغة العربية\n";
        $text .= "🇺🇸 For English language";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '🇪🇬 العربية', 'callback_data' => 'lang_ar']],
                [['text' => '🇺🇸 English', 'callback_data' => 'lang_en']],
                [['text' => '🔙 رجوع', 'callback_data' => 'main_menu']]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }
    
    private function handleLanguageChange($chatId, $user, $newLang, $messageId)
    {
        // Update user language in database
        $this->userModel->updateLanguage($user['id'], $newLang);
        
        $text = ($newLang === 'ar') ? 
            "✅ تم تغيير اللغة إلى العربية بنجاح!" : 
            "✅ Language changed to English successfully!";
        
        $this->editMessage($chatId, $messageId, $text, $this->getMainMenuKeyboard($newLang));
    }
    
    private function handleActiveReservations($chatId, $user, $lang, $messageId = null)
    {
        $activeReservations = $this->reservationModel->getUserActiveReservations($user['id']);
        
        if (empty($activeReservations)) {
            $text = "📋 لا توجد حجوزات نشطة حالياً\n\n";
            $text .= "🔍 جرب حجز رقم جديد من قائمة الخدمات";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🛍️ حجز رقم جديد', 'callback_data' => 'services']],
                    [['text' => '🔙 رجوع', 'callback_data' => 'main_menu']]
                ]
            ];
        } else {
            $text = "📋 حجوزاتك النشطة (" . count($activeReservations) . "):\n\n";
            
            $keyboard = ['inline_keyboard' => []];
            
            foreach ($activeReservations as $index => $reservation) {
                $service = $this->serviceModel->findById($reservation['service_id']);
                $timeLeft = $this->calculateTimeLeft($reservation['expires_at']);
                
                $text .= "📱 {$service['name']}\n";
                $text .= "📞 الرقم: {$reservation['phone_number']}\n";
                $text .= "⏰ متبقي: {$timeLeft}\n";
                $text .= "🔄 الحالة: في انتظار الرمز\n\n";
                
                if ($index < 3) { // Show buttons for first 3 reservations only
                    $keyboard['inline_keyboard'][] = [
                        ['text' => "🔄 {$service['name']}", 'callback_data' => "check_code_{$reservation['id']}"],
                        ['text' => "❌ إلغاء", 'callback_data' => "cancel_reservation_{$reservation['id']}"]
                    ];
                }
            }
            
            $keyboard['inline_keyboard'][] = [
                ['text' => '🔙 رجوع', 'callback_data' => 'main_menu']
            ];
        }
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }
    
    private function calculateTimeLeft($expiresAt)
    {
        $now = new \DateTime();
        $expires = new \DateTime($expiresAt);
        
        if ($expires <= $now) {
            return "انتهت الصلاحية";
        }
        
        $diff = $now->diff($expires);
        
        if ($diff->i > 0) {
            return $diff->i . " دقائق";
        } elseif ($diff->s > 0) {
            return $diff->s . " ثانية";
        }
        
        return "انتهت الصلاحية";
    }

    private function loadMaintenanceMode()
    {
        // Load maintenance mode from environment or database
        $this->maintenanceMode = (getenv('MAINTENANCE_MODE') === 'true');
    }
    
    private function sendMaintenanceMessage($chatId)
    {
        $text = "🔧 البوت قيد الصيانة حالياً\n\n";
        $text .= "⏰ نعتذر عن الإزعاج، نحن نقوم بتحسينات على النظام\n";
        $text .= "🔄 سيعود البوت للعمل قريباً\n\n";
        $text .= "📞 للاستفسار: @support";
        
        $this->sendMessage($chatId, $text);
    }
    
    public function enableMaintenanceMode($enabled = true)
    {
        $this->maintenanceMode = $enabled;
        // Could save to database or config file here
    }
    
    public function isMaintenanceMode()
    {
        return $this->maintenanceMode;
    }

    // Helper methods
    private function getSetting($key, $default = null)
    {
        // Implementation for getting bot settings
        $stmt = Database::getInstance()->getConnection()->prepare(
            "SELECT setting_value FROM bot_settings WHERE setting_key = ?"
        );
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        return $result ? $result['setting_value'] : $default;
    }

    private function isMaintenanceMode()
    {
        return $this->getSetting('maintenance_mode', '0') === '1';
    }

    // API methods
    public function sendMessage($chatId, $text, $keyboard = null)
    {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        return $this->callAPI('sendMessage', $data);
    }

    public function editMessage($chatId, $messageId, $text, $keyboard = null)
    {
        $data = [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        return $this->callAPI('editMessageText', $data);
    }

    public function answerCallbackQuery($callbackQueryId, $text = null)
    {
        $data = ['callback_query_id' => $callbackQueryId];
        if ($text) {
            $data['text'] = $text;
        }
        
        return $this->callAPI('answerCallbackQuery', $data);
    }

    private function callAPI($method, $data)
    {
        $url = $this->apiUrl . '/' . $method;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($result, true);
    }
}
<?php

namespace TelegramBot;

class Config
{
    public static function get($key, $default = null)
    {
        return $_ENV[$key] ?? $default;
    }

    public static function getBotToken()
    {
        return self::get('BOT_TOKEN', '8322142454:AAHbecdE8ann8rxkO14yjLK34R4w2sO5eVs');
    }

    public static function getAdminId()
    {
        return (int) self::get('ADMIN_ID', 0);
    }

    public static function getAdminPassword()
    {
        return self::get('ADMIN_PASSWORD', 'admin123');
    }

    public static function getDatabaseUrl()
    {
        return self::get('DATABASE_URL');
    }

    public static function getReservationTimeout()
    {
        return (int) self::get('RESERVATION_TIMEOUT_MIN', 20);
    }

    public static function getDefaultReward()
    {
        return (float) self::get('DEFAULT_REWARD_AMOUNT', 5.0);
    }

    public static function getPageSize()
    {
        return (int) self::get('PAGE_SIZE', 10);
    }
}
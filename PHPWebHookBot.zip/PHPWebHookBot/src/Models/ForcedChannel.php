<?php

namespace TelegramBot\Models;

use TelegramBot\Database;
use PDO;

class ForcedChannel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getAll()
    {
        $stmt = $this->db->prepare("
            SELECT * FROM forced_channels 
            WHERE active = 1 
            ORDER BY reward_amount DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM forced_channels WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data)
    {
        $stmt = $this->db->prepare("
            INSERT INTO forced_channels (title, username_or_link, channel_id, reward_amount, frequency) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $data['title'],
            $data['username_or_link'],
            $data['channel_id'],
            $data['reward_amount'] ?? 5.0,
            $data['frequency'] ?? 'once'
        ]);
    }

    public function update($id, $data)
    {
        $stmt = $this->db->prepare("
            UPDATE forced_channels 
            SET title = ?, username_or_link = ?, channel_id = ?, reward_amount = ?, frequency = ?, active = ?
            WHERE id = ?
        ");
        
        return $stmt->execute([
            $data['title'],
            $data['username_or_link'],
            $data['channel_id'],
            $data['reward_amount'],
            $data['frequency'],
            $data['active'] ?? 1,
            $id
        ]);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM forced_channels WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function checkUserSubscription($userId, $channelId)
    {
        $stmt = $this->db->prepare("
            SELECT last_reward_at, times_rewarded 
            FROM user_channel_rewards 
            WHERE user_id = ? AND channel_id = ?
        ");
        $stmt->execute([$userId, $channelId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function recordReward($userId, $channelId, $amount)
    {
        $stmt = $this->db->prepare("
            INSERT OR REPLACE INTO user_channel_rewards 
            (user_id, channel_id, last_reward_at, times_rewarded) 
            VALUES (?, ?, datetime('now'), 
                COALESCE((SELECT times_rewarded FROM user_channel_rewards WHERE user_id = ? AND channel_id = ?), 0) + 1)
        ");
        
        return $stmt->execute([$userId, $channelId, $userId, $channelId]);
    }

    public function canReceiveReward($userId, $channelId, $frequency = 'once')
    {
        if ($frequency === 'once') {
            $subscription = $this->checkUserSubscription($userId, $channelId);
            return !$subscription || $subscription['times_rewarded'] == 0;
        }
        
        // For daily/weekly rewards, check last reward time
        $subscription = $this->checkUserSubscription($userId, $channelId);
        if (!$subscription || !$subscription['last_reward_at']) {
            return true;
        }
        
        $lastReward = strtotime($subscription['last_reward_at']);
        $now = time();
        
        switch ($frequency) {
            case 'daily':
                return ($now - $lastReward) >= (24 * 60 * 60);
            case 'weekly':
                return ($now - $lastReward) >= (7 * 24 * 60 * 60);
            default:
                return false;
        }
    }
}
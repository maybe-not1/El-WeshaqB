<?php

namespace TelegramBot\Models;

use TelegramBot\Database;

class Number
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAvailableNumbers($serviceId, $countryCode = null)
    {
        $sql = "SELECT * FROM numbers WHERE service_id = ? AND status = 'available'";
        $params = [$serviceId];
        
        if ($countryCode) {
            $sql .= " AND country_code = ?";
            $params[] = $countryCode;
        }
        
        $sql .= " ORDER BY id LIMIT 10";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function reserve($numberId, $userId, $expiresAt)
    {
        return $this->db->query(
            "UPDATE numbers SET status = 'reserved', reserved_by_user_id = ?, reserved_at = NOW(), expires_at = ? WHERE id = ? AND status = 'available'",
            [$userId, $expiresAt, $numberId]
        );
    }

    public function findById($id)
    {
        return $this->db->fetchOne("SELECT * FROM numbers WHERE id = ?", [$id]);
    }

    public function markAsUsed($id)
    {
        $this->db->query(
            "UPDATE numbers SET status = 'used', usage_count = usage_count + 1, code_received_at = NOW() WHERE id = ?",
            [$id]
        );
        
        // Auto-delete numbers after 3 uses
        $this->db->query(
            "UPDATE numbers SET status = 'deleted' WHERE id = ? AND usage_count >= 3",
            [$id]
        );
    }

    public function cleanupExpired()
    {
        return $this->db->query(
            "UPDATE numbers SET status = 'available', reserved_by_user_id = NULL, reserved_at = NULL, expires_at = NULL WHERE expires_at < NOW() AND status = 'reserved'"
        );
    }

    public function create($data)
    {
        return $this->db->insert('numbers', $data);
    }
}
<?php

namespace TelegramBot\Models;

use TelegramBot\Database;
use PDO;

class Reservation
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($userId, $serviceId, $numberId, $pricePaid)
    {
        $stmt = $this->db->prepare("
            INSERT INTO reservations (user_id, service_id, number_id, status, price_paid) 
            VALUES (?, ?, ?, 'waiting_code', ?)
        ");
        
        $result = $stmt->execute([$userId, $serviceId, $numberId, $pricePaid]);
        
        if ($result) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    public function findByUserAndStatus($userId, $status = 'waiting_code')
    {
        $stmt = $this->db->prepare("
            SELECT r.*, n.phone_number, s.name as service_name, s.emoji
            FROM reservations r 
            JOIN numbers n ON r.number_id = n.id 
            JOIN services s ON r.service_id = s.id 
            WHERE r.user_id = ? AND r.status = ? 
            ORDER BY r.created_at DESC
        ");
        
        $stmt->execute([$userId, $status]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findActiveByUser($userId)
    {
        $stmt = $this->db->prepare("
            SELECT r.*, s.name as service_name, s.emoji, n.phone_number
            FROM reservations r
            JOIN services s ON r.service_id = s.id
            JOIN numbers n ON r.number_id = n.id
            WHERE r.user_id = ? AND r.status = 'waiting_code'
            ORDER BY r.created_at DESC
        ");
        
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($reservationId)
    {
        $stmt = $this->db->prepare("
            SELECT r.*, s.name as service_name, s.emoji, n.phone_number
            FROM reservations r
            JOIN services s ON r.service_id = s.id
            JOIN numbers n ON r.number_id = n.id
            WHERE r.id = ?
        ");
        
        $stmt->execute([$reservationId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function complete($id, $code)
    {
        $stmt = $this->db->prepare("
            UPDATE reservations 
            SET status = 'completed', code_value = ?, completed_at = datetime('now') 
            WHERE id = ?
        ");
        
        return $stmt->execute([$code, $id]);
    }

    public function expire($id)
    {
        $stmt = $this->db->prepare("
            UPDATE reservations 
            SET status = 'expired', expired_at = datetime('now') 
            WHERE id = ?
        ");
        
        return $stmt->execute([$id]);
    }

    public function cancel($reservationId)
    {
        $stmt = $this->db->prepare("
            UPDATE reservations 
            SET status = 'cancelled', expired_at = datetime('now') 
            WHERE id = ?
        ");
        
        return $stmt->execute([$reservationId]);
    }

    public function getUserHistory($userId, $limit = 20)
    {
        $stmt = $this->db->prepare("
            SELECT r.*, s.name as service_name, s.emoji, n.phone_number
            FROM reservations r
            JOIN services s ON r.service_id = s.id
            JOIN numbers n ON r.number_id = n.id
            WHERE r.user_id = ?
            ORDER BY r.created_at DESC
            LIMIT ?
        ");
        
        $stmt->execute([$userId, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function cleanupExpired()
    {
        $stmt = $this->db->prepare("
            UPDATE reservations 
            SET status = 'expired', expired_at = datetime('now') 
            WHERE status = 'waiting_code' 
            AND datetime(created_at, '+20 minutes') < datetime('now')
        ");
        
        return $stmt->execute();
    }

    public function getStats()
    {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'waiting_code' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired
            FROM reservations
        ");
        
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
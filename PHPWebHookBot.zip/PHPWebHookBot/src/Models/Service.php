<?php

namespace TelegramBot\Models;

use TelegramBot\Database;

class Service
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll()
    {
        return $this->db->fetchAll("SELECT * FROM services WHERE active = true ORDER BY name");
    }

    public function findById($id)
    {
        return $this->db->fetchOne("SELECT * FROM services WHERE id = ?", [$id]);
    }

    public function create($data)
    {
        return $this->db->insert('services', $data);
    }

    public function update($id, $data)
    {
        return $this->db->update('services', $data, ['id' => $id]);
    }

    public function delete($id)
    {
        return $this->db->update('services', ['active' => false], ['id' => $id]);
    }

    public function getServiceCountries($serviceId)
    {
        return $this->db->fetchAll(
            "SELECT * FROM service_countries WHERE service_id = ? AND active = true",
            [$serviceId]
        );
    }
}
<?php

namespace TelegramBot\Models;

use TelegramBot\Database;
use PDO;

class Transaction
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($userId, $type, $amount, $reason = null, $serviceId = null, $numberId = null, $referenceId = null)
    {
        $stmt = $this->db->prepare("
            INSERT INTO transactions (user_id, type, amount, reason, service_id, number_id, reference_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([$userId, $type, $amount, $reason, $serviceId, $numberId, $referenceId]);
    }

    public function getUserHistory($userId, $limit = 50)
    {
        $stmt = $this->db->prepare("
            SELECT t.*, s.name as service_name, s.emoji 
            FROM transactions t
            LEFT JOIN services s ON t.service_id = s.id
            WHERE t.user_id = ?
            ORDER BY t.created_at DESC
            LIMIT ?
        ");
        
        $stmt->execute([$userId, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUserStats($userId)
    {
        $stmt = $this->db->prepare("
            SELECT 
                SUM(CASE WHEN type = 'add' THEN amount ELSE 0 END) as total_added,
                SUM(CASE WHEN type = 'deduct' OR type = 'purchase' THEN amount ELSE 0 END) as total_spent,
                SUM(CASE WHEN type = 'reward' THEN amount ELSE 0 END) as total_rewards,
                COUNT(*) as total_transactions
            FROM transactions
            WHERE user_id = ?
        ");
        
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getTotalStats()
    {
        $stmt = $this->db->prepare("
            SELECT 
                SUM(CASE WHEN type = 'add' THEN amount ELSE 0 END) as total_deposits,
                SUM(CASE WHEN type = 'deduct' OR type = 'purchase' THEN amount ELSE 0 END) as total_purchases,
                SUM(CASE WHEN type = 'reward' THEN amount ELSE 0 END) as total_rewards,
                COUNT(DISTINCT user_id) as active_users,
                COUNT(*) as total_transactions
            FROM transactions
        ");
        
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getRecentTransactions($limit = 100)
    {
        $stmt = $this->db->prepare("
            SELECT t.*, u.username, u.first_name, s.name as service_name
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            LEFT JOIN services s ON t.service_id = s.id
            ORDER BY t.created_at DESC
            LIMIT ?
        ");
        
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
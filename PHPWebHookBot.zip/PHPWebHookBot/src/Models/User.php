<?php

namespace TelegramBot\Models;

use TelegramBot\Database;

class User
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function findByTelegramId($telegramId)
    {
        return $this->db->fetchOne(
            "SELECT * FROM users WHERE telegram_id = ?",
            [$telegramId]
        );
    }

    public function create($data)
    {
        return $this->db->insert('users', $data);
    }

    public function updateBalance($userId, $amount)
    {
        return $this->db->query(
            "UPDATE users SET balance = balance + ? WHERE id = ?",
            [$amount, $userId]
        );
    }

    public function getOrCreate($telegramId, $username = null, $firstName = null, $lastName = null)
    {
        $user = $this->findByTelegramId($telegramId);
        
        if (!$user) {
            $userData = [
                'telegram_id' => $telegramId,
                'username' => $username,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'balance' => 0,
                'joined_at' => date('Y-m-d H:i:s'),
                'is_admin' => 0,
                'is_banned' => 0,
                'language_code' => 'ar'
            ];
            
            $userId = $this->create($userData);
            $user = $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
        }
        
        return $user;
    }

    public function isAdmin($telegramId)
    {
        $user = $this->findByTelegramId($telegramId);
        return $user && ($user['is_admin'] || $telegramId == \TelegramBot\Config::getAdminId());
    }

    public function addBalance($userId, $amount, $reason = 'Admin adjustment')
    {
        $this->db->getConnection()->beginTransaction();
        try {
            // Update user balance
            $this->updateBalance($userId, $amount);
            
            // Add transaction record
            $this->db->insert('transactions', [
                'user_id' => $userId,
                'type' => $amount > 0 ? 'add' : 'deduct',
                'amount' => abs($amount),
                'reason' => $reason,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $this->db->getConnection()->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->getConnection()->rollback();
            throw $e;
        }
    }

    public function updateLanguage($userId, $langCode)
    {
        return $this->db->update('users', ['language_code' => $langCode], ['id' => $userId]);
    }
}
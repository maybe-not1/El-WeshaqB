<?php

namespace TelegramBot\Models;

use TelegramBot\Database;
use PDO;

class UserState
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function setState($userId, $state, $data = null)
    {
        $stmt = $this->db->prepare("
            INSERT OR REPLACE INTO user_states (user_id, state, data, updated_at) 
            VALUES (?, ?, ?, datetime('now'))
        ");
        
        return $stmt->execute([
            $userId,
            $state,
            $data ? json_encode($data) : null
        ]);
    }

    public function getState($userId)
    {
        $stmt = $this->db->prepare("
            SELECT state, data FROM user_states WHERE user_id = ?
        ");
        
        $stmt->execute([$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            return ['state' => 'idle', 'data' => null];
        }
        
        return [
            'state' => $result['state'],
            'data' => $result['data'] ? json_decode($result['data'], true) : null
        ];
    }

    public function clearState($userId)
    {
        $stmt = $this->db->prepare("DELETE FROM user_states WHERE user_id = ?");
        return $stmt->execute([$userId]);
    }

    public function updateStateData($userId, $data)
    {
        $stmt = $this->db->prepare("
            UPDATE user_states SET data = ?, updated_at = datetime('now') 
            WHERE user_id = ?
        ");
        
        return $stmt->execute([
            json_encode($data),
            $userId
        ]);
    }
}
<?php

namespace TelegramBot;

use TelegramBot\Models\Service;
use TelegramBot\Models\Number;
use TelegramBot\Models\Country;
use TelegramBot\Models\Reservation;
use TelegramBot\Models\Transaction;
use TelegramBot\Models\UserState;

class ServiceSelection
{
    private $bot;
    private $serviceModel;
    private $numberModel;
    private $countryModel;
    private $reservationModel;
    private $transactionModel;
    private $userStateModel;

    public function __construct($bot)
    {
        $this->bot = $bot;
        $this->serviceModel = new Service();
        $this->numberModel = new Number();
        $this->countryModel = new Country();
        $this->reservationModel = new Reservation();
        $this->transactionModel = new Transaction();
        $this->userStateModel = new UserState();
    }

    public function handleServiceSelection($chatId, $serviceId, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        
        if (!$service || !$service['active']) {
            $this->bot->editMessage($chatId, $messageId, "❌ الخدمة غير متاحة حالياً", [
                'inline_keyboard' => [
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ]);
            return;
        }

        // Get available countries for this service
        $countries = $this->getAvailableCountriesForService($serviceId);
        
        if (empty($countries)) {
            $text = "❌ لا توجد أرقام متاحة لخدمة {$service['name']} حالياً";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ];
        } else {
            $text = "{$service['emoji']} خدمة {$service['name']}\n\n";
            $text .= "🌍 اختر الدولة:\n";
            $text .= "💰 السعر: {$service['default_price']} جنيه";
            
            $keyboard = ['inline_keyboard' => []];
            $row = [];
            
            foreach ($countries as $index => $country) {
                $row[] = [
                    'text' => $country['flag'] . ' ' . $country['name'],
                    'callback_data' => "country_{$serviceId}_{$country['code']}"
                ];
                
                // Two countries per row
                if (($index + 1) % 2 === 0 || $index === count($countries) - 1) {
                    $keyboard['inline_keyboard'][] = $row;
                    $row = [];
                }
            }
            
            $keyboard['inline_keyboard'][] = [
                ['text' => '🔙 رجوع للخدمات', 'callback_data' => 'services'],
                ['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']
            ];
        }
        
        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    public function handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        $country = $this->countryModel->findByCode($countryCode);
        
        if (!$service || !$country) {
            $this->bot->editMessage($chatId, $messageId, "❌ خطأ في البيانات", [
                'inline_keyboard' => [
                    [['text' => '🔙 رجوع', 'callback_data' => 'services']]
                ]
            ]);
            return;
        }

        // Check user balance
        $price = $service['default_price'];
        if ($user['balance'] < $price) {
            $text = "❌ رصيدك غير كافٍ!\n\n";
            $text .= "💰 رصيدك الحالي: {$user['balance']} جنيه\n";
            $text .= "💳 السعر المطلوب: {$price} جنيه\n\n";
            $text .= "🎁 يمكنك الحصول على رصيد مجاني من خلال الاشتراك في قنواتنا!";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🆓 رصيد مجاني', 'callback_data' => 'free_balance']],
                    [['text' => '🔙 رجوع', 'callback_data' => "service_{$serviceId}"]]
                ]
            ];
            
            $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }

        // Check available numbers
        $availableNumbers = $this->numberModel->getAvailableNumbers($serviceId, $countryCode);
        $totalNumbers = count($availableNumbers);
        
        if ($totalNumbers === 0) {
            $text = "❌ لا توجد أرقام متاحة\n\n";
            $text .= "{$service['emoji']} الخدمة: {$service['name']}\n";
            $text .= "{$country['flag']} الدولة: {$country['name']}\n\n";
            $text .= "⏰ يرجى المحاولة لاحقاً";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔄 إعادة المحاولة', 'callback_data' => "country_{$serviceId}_{$countryCode}"]],
                    [['text' => '🔙 رجوع', 'callback_data' => "service_{$serviceId}"]]
                ]
            ];
        } else {
            $text = "✅ أرقام متاحة!\n\n";
            $text .= "{$service['emoji']} الخدمة: {$service['name']}\n";
            $text .= "{$country['flag']} الدولة: {$country['name']}\n";
            $text .= "💰 السعر: {$price} جنيه\n";
            $text .= "📱 الأرقام المتاحة: {$totalNumbers}\n\n";
            $text .= "⚡ سيتم حجز رقم عشوائي وخصم المبلغ من رصيدك فور وصول كود التحقق";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔒 احجز رقم الآن', 'callback_data' => "reserve_{$serviceId}_{$countryCode}"]],
                    [
                        ['text' => '🌍 تغيير الدولة', 'callback_data' => "service_{$serviceId}"],
                        ['text' => '📱 تغيير الخدمة', 'callback_data' => 'services']
                    ],
                    [['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']]
                ]
            ];
        }
        
        $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
    }

    public function handleNumberReservation($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        $country = $this->countryModel->findByCode($countryCode);
        
        if (!$service || !$country) {
            $this->bot->answerCallbackQuery($callbackQuery['id'], "❌ خطأ في البيانات");
            return;
        }

        // Check user balance again
        $price = $service['default_price'];
        if ($user['balance'] < $price) {
            $this->bot->answerCallbackQuery($callbackQuery['id'], "❌ رصيدك غير كافٍ!");
            return;
        }

        // Check concurrent reservations limit
        $activeReservations = $this->reservationModel->findActiveByUser($user['id']);
        $maxReservations = $this->getSetting('max_concurrent_reservations', 3);
        
        if (count($activeReservations) >= $maxReservations) {
            $text = "⚠️ تم الوصول للحد الأقصى\n\n";
            $text .= "📊 الحجوزات النشطة: " . count($activeReservations) . " / {$maxReservations}\n\n";
            $text .= "يرجى انتظار وصول الأكواد للحجوزات الحالية أو إلغاؤها قبل حجز أرقام جديدة";
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '📋 حجوزاتي النشطة', 'callback_data' => 'my_reservations']],
                    [['text' => '🔙 رجوع', 'callback_data' => "country_{$serviceId}_{$countryCode}"]]
                ]
            ];
            
            $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }

        // Get available number
        $availableNumbers = $this->numberModel->getAvailableNumbers($serviceId, $countryCode, 1);
        
        if (empty($availableNumbers)) {
            $this->bot->answerCallbackQuery($callbackQuery['id'], "❌ لا توجد أرقام متاحة");
            return;
        }

        $number = $availableNumbers[0];
        
        try {
            // Start transaction
            $this->numberModel->reserveNumber($number['id'], $user['id']);
            $reservationId = $this->reservationModel->create($user['id'], $serviceId, $number['id'], $price);
            
            if ($reservationId) {
                // Set reservation timeout (20 minutes default)
                $timeoutMinutes = $this->getSetting('reservation_timeout_minutes', 20);
                
                $text = "✅ تم حجز الرقم بنجاح!\n\n";
                $text .= "{$service['emoji']} الخدمة: {$service['name']}\n";
                $text .= "{$country['flag']} الدولة: {$country['name']}\n";
                $text .= "📱 الرقم: <code>{$number['phone_number']}</code>\n";
                $text .= "⏰ مهلة الانتظار: {$timeoutMinutes} دقيقة\n\n";
                $text .= "🔔 سيتم إرسال كود التحقق فور وصوله\n";
                $text .= "💰 سيتم خصم {$price} جنيه عند وصول الكود";
                
                $keyboard = [
                    'inline_keyboard' => [
                        [['text' => '🔄 تغيير الرقم', 'callback_data' => "change_number_{$reservationId}"]],
                        [
                            ['text' => '🌍 تغيير الدولة', 'callback_data' => "service_{$serviceId}"],
                            ['text' => '❌ إلغاء الحجز', 'callback_data' => "cancel_reservation_{$reservationId}"]
                        ],
                        [['text' => '🏠 الرئيسية', 'callback_data' => 'main_menu']]
                    ]
                ];
                
                $this->bot->editMessage($chatId, $messageId, $text, $keyboard);
                
                // Log the reservation
                error_log("New reservation: User {$user['id']} reserved number {$number['phone_number']} for service {$service['name']}");
                
            } else {
                throw new \Exception("Failed to create reservation");
            }
            
        } catch (\Exception $e) {
            error_log("Reservation error: " . $e->getMessage());
            $this->bot->answerCallbackQuery($callbackQuery['id'], "❌ خطأ في الحجز، يرجى المحاولة مرة أخرى");
        }
    }

    private function getAvailableCountriesForService($serviceId)
    {
        return $this->numberModel->getCountriesWithNumbers($serviceId);
    }

    private function getSetting($key, $default = null)
    {
        // Get from bot_settings table
        return $default; // Placeholder - implement actual settings retrieval
    }
}
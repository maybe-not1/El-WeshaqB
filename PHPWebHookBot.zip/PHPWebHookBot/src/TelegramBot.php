<?php

namespace TelegramBot;

use TelegramBot\Models\User;
use TelegramBot\Models\Service;
use TelegramBot\Models\Number;
use TelegramBot\Models\Reservation;

class TelegramBot
{
    private $apiUrl;
    private $userModel;
    private $serviceModel;
    private $numberModel;
    private $reservationModel;
    private $adminPanel;

    public function __construct()
    {
        $token = Config::getBotToken();
        if (!$token) {
            throw new \Exception('BOT_TOKEN not found in environment');
        }
        
        $this->apiUrl = "https://api.telegram.org/bot{$token}";
        $this->userModel = new User();
        $this->serviceModel = new Service();
        $this->numberModel = new Number();
        $this->reservationModel = new Reservation();
        $this->adminPanel = new \TelegramBot\AdminPanel($this);
    }

    public function handleUpdate($update)
    {
        try {
            if (isset($update['message'])) {
                $this->handleMessage($update['message']);
            } elseif (isset($update['callback_query'])) {
                $this->handleCallbackQuery($update['callback_query']);
            }
        } catch (\Exception $e) {
            error_log('Bot error: ' . $e->getMessage());
        }
    }

    private function handleMessage($message)
    {
        $chatId = $message['chat']['id'];
        $userId = $message['from']['id'];
        $text = $message['text'] ?? '';
        $username = $message['from']['username'] ?? null;
        $firstName = $message['from']['first_name'] ?? null;
        $lastName = $message['from']['last_name'] ?? null;

        // Get or create user
        $user = $this->userModel->getOrCreate($userId, $username, $firstName, $lastName);
        $lang = $user['language_code'] ?? 'ar';

        // Handle commands
        if ($text === '/start') {
            $this->handleStart($chatId, $lang);
        } elseif ($text === '/balance') {
            $this->handleBalance($chatId, $user, $lang);
        } elseif ($text === '/services') {
            $this->handleServices($chatId, $lang);
        } elseif ($text === '/admin' && $this->userModel->isAdmin($userId)) {
            $this->adminPanel->showMainPanel($chatId, $lang);
        } elseif ($text === '/help') {
            $help = "🤖 بوت خدمات الأرقام المؤقتة\n\n";
            $help .= "📱 /services - عرض الخدمات\n";
            $help .= "💰 /balance - عرض الرصيد\n";
            $help .= "🏠 /start - العودة للرئيسية\n";
            $this->sendMessage($chatId, $help);
        } else {
            $this->handleMainMenu($chatId, $lang);
        }
    }

    private function handleCallbackQuery($callbackQuery)
    {
        $chatId = $callbackQuery['message']['chat']['id'];
        $userId = $callbackQuery['from']['id'];
        $data = $callbackQuery['data'];
        $messageId = $callbackQuery['message']['message_id'];

        $user = $this->userModel->findByTelegramId($userId);
        $lang = $user['language_code'] ?? 'ar';

        // Answer callback query
        $this->answerCallbackQuery($callbackQuery['id']);

        if (strpos($data, 'service_') === 0) {
            $serviceId = (int) str_replace('service_', '', $data);
            $this->handleServiceSelection($chatId, $serviceId, $lang, $messageId);
        } elseif (strpos($data, 'country_') === 0) {
            $parts = explode('_', $data);
            $serviceId = (int) $parts[1];
            $countryCode = $parts[2];
            $this->handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId);
        } elseif ($data === 'main_menu') {
            $this->handleMainMenu($chatId, $lang, $messageId);
        } elseif ($data === 'services') {
            $this->handleServices($chatId, $lang, $messageId);
        } elseif ($data === 'balance') {
            $this->handleBalance($chatId, $user, $lang, $messageId);
        } elseif ($data === 'language') {
            $text = "🌍 اختر اللغة:";
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🇸🇦 العربية', 'callback_data' => 'lang_ar']],
                    [['text' => '🇺🇸 English', 'callback_data' => 'lang_en']],
                    [['text' => Translation::get('back', $lang), 'callback_data' => 'main_menu']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } elseif (strpos($data, 'lang_') === 0) {
            $newLang = str_replace('lang_', '', $data);
            $this->userModel->updateLanguage($user['id'], $newLang);
            $text = Translation::get('choose_option', $newLang);
            $keyboard = $this->getMainMenuKeyboard($newLang);
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } elseif (strpos($data, 'admin_') === 0 && $this->userModel->isAdmin($userId)) {
            $this->handleAdminCallback($data, $chatId, $userId, $lang, $messageId);
        }
    }

    private function handleStart($chatId, $lang)
    {
        $text = Translation::get('main_menu', $lang) . "\n";
        $text .= Translation::get('choose_option', $lang);
        $this->sendMessage($chatId, $text, $this->getMainMenuKeyboard($lang));
    }

    private function handleMainMenu($chatId, $lang, $messageId = null)
    {
        $text = Translation::get('choose_option', $lang);
        $keyboard = $this->getMainMenuKeyboard($lang);
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleBalance($chatId, $user, $lang, $messageId = null)
    {
        $text = Translation::get('current_balance', $lang, ['balance' => $user['balance']]);
        $keyboard = [
            'inline_keyboard' => [
                [['text' => Translation::get('back', $lang), 'callback_data' => 'main_menu']]
            ]
        ];
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleServices($chatId, $lang, $messageId = null)
    {
        $services = $this->serviceModel->getAll();
        
        if (empty($services)) {
            $text = Translation::get('no_services', $lang);
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => Translation::get('back', $lang), 'callback_data' => 'main_menu']]
                ]
            ];
        } else {
            $text = Translation::get('choose_service', $lang);
            $keyboard = ['inline_keyboard' => []];
            
            foreach ($services as $service) {
                $keyboard['inline_keyboard'][] = [[
                    'text' => ($service['emoji'] ?? '📱') . ' ' . $service['name'],
                    'callback_data' => 'service_' . $service['id']
                ]];
            }
            
            $keyboard['inline_keyboard'][] = [[
                'text' => Translation::get('back', $lang),
                'callback_data' => 'main_menu'
            ]];
        }
        
        if ($messageId) {
            $this->editMessage($chatId, $messageId, $text, $keyboard);
        } else {
            $this->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function handleServiceSelection($chatId, $serviceId, $lang, $messageId)
    {
        $countries = $this->serviceModel->getServiceCountries($serviceId);
        
        if (empty($countries)) {
            // If no specific countries, show available numbers directly
            $this->handleCountrySelection($chatId, $serviceId, null, 
                $this->userModel->findByTelegramId($chatId), $lang, $messageId);
            return;
        }
        
        $text = Translation::get('choose_country', $lang);
        $keyboard = ['inline_keyboard' => []];
        
        foreach ($countries as $country) {
            $keyboard['inline_keyboard'][] = [[
                'text' => ($country['flag'] ?? '🏳️') . ' ' . $country['country_name'],
                'callback_data' => "country_{$serviceId}_{$country['country_code']}"
            ]];
        }
        
        $keyboard['inline_keyboard'][] = [[
            'text' => Translation::get('back', $lang),
            'callback_data' => 'services'
        ]];
        
        $this->editMessage($chatId, $messageId, $text, $keyboard);
    }

    private function handleCountrySelection($chatId, $serviceId, $countryCode, $user, $lang, $messageId)
    {
        $service = $this->serviceModel->findById($serviceId);
        if (!$service) {
            return;
        }

        // Check balance
        if ($user['balance'] < $service['default_price']) {
            $text = Translation::get('insufficient_balance', $lang, [
                'required' => $service['default_price']
            ]);
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => Translation::get('back', $lang), 'callback_data' => 'services']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }

        $numbers = $this->numberModel->getAvailableNumbers($serviceId, $countryCode);
        
        if (empty($numbers)) {
            $text = Translation::get('no_numbers', $lang);
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => Translation::get('back', $lang), 'callback_data' => 'services']]
                ]
            ];
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            return;
        }

        // Reserve first available number
        $number = $numbers[0];
        $timeout = Config::getReservationTimeout();
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$timeout} minutes"));

        // Start transaction
        $db = Database::getInstance()->getConnection();
        $db->beginTransaction();

        try {
            // Reserve number
            $this->numberModel->reserve($number['id'], $user['id'], $expiresAt);
            
            // Deduct balance
            $this->userModel->updateBalance($user['id'], -$service['default_price']);
            
            // Create reservation
            $this->reservationModel->create([
                'user_id' => $user['id'],
                'service_id' => $serviceId,
                'number_id' => $number['id'],
                'status' => 'waiting_code',
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $db->commit();
            
            $text = Translation::get('number_reserved', $lang, [
                'number' => $number['phone_number'],
                'timeout' => $timeout
            ]);
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => Translation::get('main_menu', $lang), 'callback_data' => 'main_menu']]
                ]
            ];
            
            $this->editMessage($chatId, $messageId, $text, $keyboard);
            
        } catch (\Exception $e) {
            $db->rollback();
            error_log('Reservation error: ' . $e->getMessage());
        }
    }

    private function handleAdminCallback($data, $chatId, $userId, $lang, $messageId)
    {
        try {
            switch ($data) {
                case 'admin_main':
                    $this->adminPanel->showMainPanel($chatId, $lang, $messageId);
                    break;
                case 'admin_services':
                    $this->adminPanel->showServicesManagement($chatId, $lang, $messageId);
                    break;
                case 'admin_stats':
                    $this->adminPanel->showStatistics($chatId, $lang, $messageId);
                    break;
                case 'admin_users':
                    $this->adminPanel->showUsersManagement($chatId, $lang, $messageId);
                    break;
                case 'admin_numbers':
                    $this->adminPanel->showNumbersManagement($chatId, $lang, $messageId);
                    break;
                default:
                    $this->sendMessage($chatId, "🔧 هذه الميزة قيد التطوير");
                    break;
            }
        } catch (\Exception $e) {
            error_log('Admin Panel Error: ' . $e->getMessage());
            $this->sendMessage($chatId, "❌ خطأ في لوحة الإدارة: " . $e->getMessage());
        }
    }

    private function getMainMenuKeyboard($lang)
    {
        return [
            'inline_keyboard' => [
                [
                    ['text' => Translation::get('google_service', $lang), 'callback_data' => 'service_1'],
                    ['text' => Translation::get('whatsapp_service', $lang), 'callback_data' => 'service_2']
                ],
                [
                    ['text' => Translation::get('balance', $lang), 'callback_data' => 'balance'],
                    ['text' => Translation::get('statistics', $lang), 'callback_data' => 'stats']
                ],
                [
                    ['text' => Translation::get('help_support', $lang), 'callback_data' => 'help'],
                    ['text' => Translation::get('admin_panel', $lang), 'callback_data' => 'admin_main']
                ]
            ]
        ];
    }

    private function sendMessage($chatId, $text, $keyboard = null)
    {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        return $this->apiCall('sendMessage', $data);
    }

    private function editMessage($chatId, $messageId, $text, $keyboard = null)
    {
        $data = [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        return $this->apiCall('editMessageText', $data);
    }

    private function answerCallbackQuery($callbackQueryId, $text = '')
    {
        return $this->apiCall('answerCallbackQuery', [
            'callback_query_id' => $callbackQueryId,
            'text' => $text
        ]);
    }

    private function apiCall($method, $data)
    {
        $url = $this->apiUrl . '/' . $method;
        
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => http_build_query($data)
            ]
        ];
        
        return file_get_contents($url, false, stream_context_create($options));
    }
}
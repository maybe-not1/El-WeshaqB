<?php

namespace TelegramBot;

class Translation
{
    private static $translations = [
        'main_menu' => [
            'ar' => '🌟 القائمة الرئيسية 🌟',
            'en' => '🌟 Main Menu 🌟'
        ],
        'balance' => [
            'ar' => '💰 رصيدي',
            'en' => '💰 My Balance'
        ],
        'services' => [
            'ar' => '📱 الخدمات',
            'en' => '📱 Services'
        ],
        'language' => [
            'ar' => '🌍 اللغة',
            'en' => '🌍 Language'
        ],
        'free_credits' => [
            'ar' => '🎁 رصيد مجاني',
            'en' => '🎁 Free Credits'
        ],
        'contact_support' => [
            'ar' => '📞 الدعم الفني',
            'en' => '📞 Support'
        ],
        'admin_panel' => [
            'ar' => '⚙️ لوحة الإدارة',
            'en' => '⚙️ Admin Panel'
        ],
        'back' => [
            'ar' => '🔙 رجوع',
            'en' => '🔙 Back'
        ],
        'cancel' => [
            'ar' => '❌ إلغاء',
            'en' => '❌ Cancel'
        ],
        'welcome_message' => [
            'ar' => '👋 أهلاً وسهلاً بك في بوت خدمات الأرقام المؤقتة!\n\nيمكنك استخدام الأرقام لتفعيل حساباتك في مختلف المنصات.',
            'en' => '👋 Welcome to the Temporary Numbers Service Bot!\n\nYou can use numbers to activate your accounts on various platforms.'
        ],
        'choose_option' => [
            'ar' => 'اختر خياراً:',
            'en' => 'Choose an option:'
        ],
        'current_balance' => [
            'ar' => 'رصيدك الحالي: {balance} وحدة',
            'en' => 'Your current balance: {balance} units'
        ],
        'choose_service' => [
            'ar' => 'اختر الخدمة:',
            'en' => 'Choose service:'
        ],
        'choose_country' => [
            'ar' => 'اختر الدولة:',
            'en' => 'Choose country:'
        ],
        'no_services' => [
            'ar' => 'لا توجد خدمات متاحة حالياً',
            'en' => 'No services available currently'
        ],
        'no_numbers' => [
            'ar' => 'لا توجد أرقام متاحة لهذه الخدمة',
            'en' => 'No numbers available for this service'
        ],
        'insufficient_balance' => [
            'ar' => '💰 رصيد غير كافي! تحتاج إلى {required} وحدة',
            'en' => '💰 Insufficient balance! You need {required} units'
        ],
        'number_reserved' => [
            'ar' => '✅ تم حجز الرقم بنجاح!\n📱 الرقم: {number}\n⏰ سينتهي خلال {timeout} دقيقة\n\nسيصلك الكود تلقائياً عند وصوله.',
            'en' => '✅ Number reserved successfully!\n📱 Number: {number}\n⏰ Expires in {timeout} minutes\n\nYou will receive the code automatically when it arrives.'
        ],
        'code_received' => [
            'ar' => '🎉 وصل الكود!\n📱 الرقم: {number}\n🔐 الكود: {code}',
            'en' => '🎉 Code received!\n📱 Number: {number}\n🔐 Code: {code}'
        ],
        'reservation_expired' => [
            'ar' => '⏰ انتهت صلاحية الحجز للرقم: {number}',
            'en' => '⏰ Reservation expired for number: {number}'
        ],
        'active_reservations' => [
            'ar' => '📋 حجوزاتك النشطة:',
            'en' => '📋 Your active reservations:'
        ],
        'no_active_reservations' => [
            'ar' => 'لا توجد حجوزات نشطة',
            'en' => 'No active reservations'
        ],
        'admin_panel' => [
            'ar' => '👑 لوحة الإدارة',
            'en' => '👑 Admin Panel'
        ],
        'admin_services' => [
            'ar' => '⚙️ إدارة الخدمات',
            'en' => '⚙️ Service Management'
        ],
        'admin_countries' => [
            'ar' => '🌍 إدارة البلدان',
            'en' => '🌍 Countries Management'
        ],
        'admin_numbers' => [
            'ar' => '📱 إدارة الأرقام',
            'en' => '📱 Numbers Management'
        ],
        'admin_users' => [
            'ar' => '👥 إدارة المستخدمين',
            'en' => '👥 Users Management'
        ],
        'admin_groups' => [
            'ar' => '🔗 إدارة المجموعات',
            'en' => '🔗 Groups Management'
        ],
        'admin_channels' => [
            'ar' => '📢 إدارة القنوات',
            'en' => '📢 Channels Management'
        ],
        'add_balance' => [
            'ar' => '💰 إضافة رصيد',
            'en' => '💰 Add Balance'
        ],
        'deduct_balance' => [
            'ar' => '💸 خصم رصيد',
            'en' => '💸 Deduct Balance'
        ],
        'private_message' => [
            'ar' => '💬 رسالة خاصة',
            'en' => '💬 Private Message'
        ],
        'broadcast_message' => [
            'ar' => '📢 رسالة عامة',
            'en' => '📢 Broadcast Message'
        ],
        'system_settings' => [
            'ar' => '⚙️ إعدادات النظام',
            'en' => '⚙️ System Settings'
        ],
        'statistics' => [
            'ar' => '📊 الإحصائيات',
            'en' => '📊 Statistics'
        ],
        'maintenance_mode' => [
            'ar' => '🔧 وضع الصيانة',
            'en' => '🔧 Maintenance Mode'
        ],
        'data_export' => [
            'ar' => '📋 قناة البيانات',
            'en' => '📋 Data Channel'
        ],
        'forced_subscription' => [
            'ar' => '🔔 الاشتراك الإجباري',
            'en' => '🔔 Forced Subscription'
        ],
        'password_change' => [
            'ar' => '🔒 تغيير كلمة المرور',
            'en' => '🔒 Change Password'
        ],
        'help_support' => [
            'ar' => '❓ المساعدة',
            'en' => '❓ Help & Support'
        ],
        'recent_file_success' => [
            'ar' => '🗂 تم قراءة الملف بنجاح - وجد {count} رقم',
            'en' => '🗂 File read successfully - found {count} numbers'
        ],
        'start_processing' => [
            'ar' => '🔄 بدء معالجة {count} رقم',
            'en' => '🔄 Processing {count} numbers'
        ],
        'processing_complete' => [
            'ar' => '⚡ جاري التحضير والتحليل...',
            'en' => '⚡ Preparing and analyzing...'
        ],
        'auto_update_enabled' => [
            'ar' => '🔄 سيتم التحديث تلقائياً',
            'en' => '🔄 Auto-update enabled'
        ],
        'google_service' => [
            'ar' => '📧 Google',
            'en' => '📧 Google'
        ],
        'whatsapp_service' => [
            'ar' => '💚 WhatsApp1',
            'en' => '💚 WhatsApp1'
        ],
        'welcome_user' => [
            'ar' => 'مرحباً بسيدنا في مركز التحكم المتطور 🌟',
            'en' => 'Welcome master to the advanced control center 🌟'
        ]
    ];

    public static function get($key, $lang = 'ar', $params = [])
    {
        $text = self::$translations[$key][$lang] ?? self::$translations[$key]['ar'] ?? $key;
        
        foreach ($params as $param => $value) {
            $text = str_replace('{' . $param . '}', $value, $text);
        }
        
        return $text;
    }

    public static function getLanguageOptions()
    {
        return [
            'ar' => '🇸🇦 العربية',
            'en' => '🇺🇸 English'
        ];
    }
}
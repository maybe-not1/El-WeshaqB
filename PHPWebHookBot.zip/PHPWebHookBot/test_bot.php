<?php

require_once 'vendor/autoload.php';

use TelegramBot\ComprehensiveTelegramBot;
use TelegramBot\Config;

// Load environment variables
if (file_exists(__DIR__ . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
}

echo "🤖 Testing Comprehensive Telegram Bot...\n";

try {
    // Test bot initialization
    echo "1. Initializing bot...\n";
    $bot = new ComprehensiveTelegramBot();
    echo "   ✅ Bot initialized successfully\n";
    
    // Test database connection
    echo "\n2. Testing database connection...\n";
    $db = TelegramBot\Database::getInstance();
    $connection = $db->getConnection();
    
    // Check tables exist
    $tables = ['users', 'services', 'countries', 'numbers', 'reservations', 'transactions', 'forced_channels'];
    foreach ($tables as $table) {
        $stmt = $connection->prepare("SELECT COUNT(*) FROM $table");
        $stmt->execute();
        $count = $stmt->fetchColumn();
        echo "   ✅ Table '$table' exists with $count records\n";
    }
    
    // Test services
    echo "\n3. Testing services...\n";
    $stmt = $connection->prepare("SELECT COUNT(*) FROM services WHERE active = 1");
    $stmt->execute();
    $activeServices = $stmt->fetchColumn();
    echo "   ✅ $activeServices active services found\n";
    
    // Test countries
    echo "\n4. Testing countries...\n";
    $stmt = $connection->prepare("SELECT COUNT(*) FROM countries WHERE active = 1");
    $stmt->execute();
    $activeCountries = $stmt->fetchColumn();
    echo "   ✅ $activeCountries active countries found\n";
    
    // Test forced channels
    echo "\n5. Testing forced channels...\n";
    $stmt = $connection->prepare("SELECT COUNT(*) FROM forced_channels WHERE active = 1");
    $stmt->execute();
    $activeChannels = $stmt->fetchColumn();
    echo "   ✅ $activeChannels active forced channels found\n";
    
    // Test bot settings
    echo "\n6. Testing bot settings...\n";
    $stmt = $connection->prepare("SELECT COUNT(*) FROM bot_settings");
    $stmt->execute();
    $settingsCount = $stmt->fetchColumn();
    echo "   ✅ $settingsCount bot settings configured\n";
    
    echo "\n🎉 All tests passed! Bot is ready to use.\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "📱 Bot Features Ready:\n";
    echo "  • ✅ User management and balance system\n";
    echo "  • ✅ Service and country selection\n";
    echo "  • ✅ Number reservation system\n";
    echo "  • ✅ Transaction tracking\n";
    echo "  • ✅ Forced channels for free balance\n";
    echo "  • ✅ Comprehensive admin panel\n";
    echo "  • ✅ Statistics and reporting\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    
    // Show some sample data
    echo "\n📊 Sample Data:\n";
    
    $stmt = $connection->prepare("SELECT name, emoji, default_price FROM services WHERE active = 1 LIMIT 5");
    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Services:\n";
    foreach ($services as $service) {
        echo "  {$service['emoji']} {$service['name']} - {$service['default_price']} EGP\n";
    }
    
    $stmt = $connection->prepare("SELECT name, flag, code FROM countries WHERE active = 1 LIMIT 5");
    $stmt->execute();
    $countries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nCountries:\n";
    foreach ($countries as $country) {
        echo "  {$country['flag']} {$country['name']} ({$country['code']})\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
<?php

require_once 'vendor/autoload.php';

use TelegramBot\ComprehensiveTelegramBot;

// Load environment variables
if (file_exists(__DIR__ . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
}

// Set content type for JSON response
header('Content-Type: application/json');

try {
    // Get the incoming update from Telegram
    $input = file_get_contents('php://input');
    
    if (empty($input)) {
        http_response_code(400);
        echo json_encode(['error' => 'No input data']);
        exit;
    }
    
    $update = json_decode($input, true);
    
    if (!$update) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON']);
        exit;
    }
    
    // Log the update for debugging (remove in production)
    error_log('Comprehensive Bot Update: ' . $input);
    
    // Create comprehensive bot instance and handle the update
    $bot = new ComprehensiveTelegramBot();
    $bot->handleUpdate($update);
    
    // Return success response
    echo json_encode(['ok' => true]);
    
} catch (Exception $e) {
    error_log('Comprehensive Bot Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}